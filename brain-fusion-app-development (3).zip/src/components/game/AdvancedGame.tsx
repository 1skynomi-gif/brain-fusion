import { useState, useEffect, useCallback, useRef } from 'react';
import { useStore } from '../../store/useStore';
import { generateSequence, SHAPES, COLORS, getLetterForIndex, getAlphabetLetter } from '../../utils/stimulusGenerator';
import { speakLetter, playPianoNote, speakNumber, playCorrectSound, playWrongSound, startNoise, stopNoise } from '../../utils/audio';
import { X, Pause, Play, Lock } from 'lucide-react';
import type { GeneratedStimulus } from '../../utils/stimulusGenerator';

interface ChannelResult {
  hits: number; misses: number; falseAlarms: number; correctRejections: number; accuracy: number;
}

export function AdvancedGame() {
  const { settings, advancedCore, advancedInterference, advancedTaskSwitching, setScreen, addSession, addXP } = useStore();
  const dark = settings.theme === 'dark';
  const anims = settings.animationsEnabled;

  const [phase, setPhase] = useState<'ready' | 'playing' | 'paused' | 'result'>('ready');
  const [currentIndex, setCurrentIndex] = useState(-1);
  const [sequence, setSequence] = useState<GeneratedStimulus[]>([]);
  const [responses, setResponses] = useState<Record<string, Set<number>>>({});
  const [feedback, setFeedback] = useState<{ type: 'correct' | 'wrong' | null; channel: string }>({ type: null, channel: '' });
  const [results, setResults] = useState<Record<string, ChannelResult>>({});
  const [totalAccuracy, setTotalAccuracy] = useState(0);
  const [showStimulus, setShowStimulus] = useState(false);
  const [startTime, setStartTime] = useState(0);
  const [currentN, setCurrentN] = useState(advancedCore.n);
  const [currentSpeed, setCurrentSpeed] = useState(advancedCore.speed);
  const [opacity, setOpacity] = useState(1);
  const [goNoGo, setGoNoGo] = useState(false);
  const [visualNoise, setVisualNoise] = useState(false);
  const [activeButtons, setActiveButtons] = useState<Set<string>>(new Set());
  const [fadingOpacity, setFadingOpacity] = useState(1);

  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pauseRef = useRef(false);

  const activeChannels = (() => {
    const chs: string[] = [];
    if (advancedCore.channels.position) chs.push('position');
    if (advancedCore.channels.audio1) chs.push('audio1');
    if (advancedCore.channels.audio2) chs.push('audio2');
    if (advancedCore.channels.shape) chs.push('shape');
    if (advancedCore.channels.color) chs.push('color');
    if (advancedCore.channels.vibration) chs.push('vibration');
    if (advancedCore.channels.size) chs.push('size');
    if (advancedCore.channels.texture) chs.push('texture');
    if (advancedCore.channels.visualNumbers) chs.push('visualNumber');
    if (advancedCore.channels.visualLetters) chs.push('visualLetter');
    return chs;
  })();

  const generateGame = useCallback(() => {
    const channelN: Record<string, number> = {};
    if (advancedTaskSwitching.multiChannelN) {
      for (const ch of activeChannels) {
        channelN[ch] = advancedTaskSwitching.channelNValues[ch] ?? advancedCore.n;
      }
    }

    const seq = generateSequence({
      n: advancedCore.n,
      totalStimuli: advancedCore.stimuliCount,
      matchPercent: advancedCore.matchPercent,
      channels: activeChannels,
      gridSize: advancedCore.gridSize,
      lurePercent: advancedInterference.lureTrials,
      channelN: advancedTaskSwitching.multiChannelN ? channelN : undefined,
    });
    setSequence(seq);
    const initResponses: Record<string, Set<number>> = {};
    for (const ch of activeChannels) initResponses[ch] = new Set();
    setResponses(initResponses);
    setCurrentIndex(-1);
    setCurrentN(advancedCore.n);
    setCurrentSpeed(advancedCore.speed);
    setActiveButtons(new Set(activeChannels));
  }, [advancedCore, advancedInterference.lureTrials, advancedTaskSwitching, activeChannels]);

  useEffect(() => { generateGame(); }, []);

  const startGame = useCallback(() => {
    setPhase('playing');
    setStartTime(Date.now());
    setCurrentIndex(0);
    setShowStimulus(true);
    if (advancedInterference.noiseType !== 'none') {
      startNoise(advancedInterference.noiseType, advancedInterference.noiseIntensity);
    }
  }, [advancedInterference.noiseType, advancedInterference.noiseIntensity]);

  // Main game loop
  useEffect(() => {
    if (phase !== 'playing' || currentIndex < 0 || currentIndex >= sequence.length) return;

    const stim = sequence[currentIndex];

    // Play audio
    if (stim.stimulus.audio1 !== undefined && advancedCore.channels.audio1) {
      const types = advancedCore.channels.audio1Type;
      const type = types[Math.floor(Math.random() * types.length)];
      const rate = Math.max(0.7, Math.min(2.5, 2500 / currentSpeed));
      if (type === 'piano') playPianoNote(stim.stimulus.audio1, currentSpeed * 0.7, 1);
      else if (type === 'letters') speakLetter(getLetterForIndex(stim.stimulus.audio1), rate);
      else speakNumber((stim.stimulus.audio1 % 20) + 1, rate);
    }

    if (stim.stimulus.audio2 !== undefined && advancedCore.channels.audio2) {
      const types = advancedCore.channels.audio2Type;
      const type = types[Math.floor(Math.random() * types.length)];
      if (type === 'piano') playPianoNote(stim.stimulus.audio2, currentSpeed * 0.7, -1);
    }

    // Fading effect
    if (advancedInterference.fadingEnabled) {
      setFadingOpacity(1);
      const fadeStart = currentSpeed * 0.2;
      const fadeDuration = currentSpeed * (0.3 + (advancedInterference.fadingIntensity / 10) * 0.5);
      setTimeout(() => {
        setFadingOpacity(0);
      }, fadeStart);
      setTimeout(() => {}, fadeStart + fadeDuration);
    }

    // Random opacity effect
    if (advancedInterference.opacityEnabled) {
      const chance = advancedInterference.opacityIntensity / 10;
      if (Math.random() < chance) {
        setOpacity(0.2 + Math.random() * 0.3);
        setTimeout(() => setOpacity(1), currentSpeed * 0.6);
      }
    }

    // Go/No-Go
    if (advancedInterference.goNoGoEnabled) {
      const chance = advancedInterference.goNoGoIntensity / 15;
      if (Math.random() < chance) {
        setGoNoGo(true);
        setTimeout(() => setGoNoGo(false), currentSpeed * 0.8);
      }
    }

    // Visual noise
    if (advancedInterference.visualNoiseEnabled) {
      const chance = advancedInterference.visualNoiseIntensity / 10;
      setVisualNoise(Math.random() < chance);
    }

    // Dynamic N
    if (advancedTaskSwitching.dynamicN) {
      const chance = advancedTaskSwitching.dynamicNIntensity / 10;
      if (Math.random() < chance) {
        const newN = Math.floor(Math.random() * (advancedTaskSwitching.dynamicNMax - advancedTaskSwitching.dynamicNMin + 1)) + advancedTaskSwitching.dynamicNMin;
        setCurrentN(newN);
      }
    }

    // Dynamic Speed
    if (advancedTaskSwitching.dynamicSpeed) {
      const chance = advancedTaskSwitching.dynamicSpeedIntensity / 10;
      if (Math.random() < chance) {
        const newSpeed = Math.floor(Math.random() * (advancedTaskSwitching.dynamicSpeedMax - advancedTaskSwitching.dynamicSpeedMin + 1)) + advancedTaskSwitching.dynamicSpeedMin;
        setCurrentSpeed(newSpeed);
      }
    }

    // Channel switching
    if (advancedTaskSwitching.channelSwitching) {
      const chance = advancedTaskSwitching.channelSwitchingIntensity / 12;
      if (Math.random() < chance) {
        const numToShow = Math.max(1, Math.floor(Math.random() * activeChannels.length));
        const shuffled = [...activeChannels].sort(() => Math.random() - 0.5);
        setActiveButtons(new Set(shuffled.slice(0, numToShow)));
      }
    }

    setShowStimulus(true);
    const showTimer = setTimeout(() => setShowStimulus(false), Math.min(currentSpeed * 0.8, currentSpeed - 100));

    timerRef.current = setTimeout(() => {
      if (pauseRef.current) return;
      setCurrentIndex(prev => {
        if (prev >= sequence.length - 1) {
          setPhase('result');
          stopNoise();
          return prev;
        }
        return prev + 1;
      });
    }, currentSpeed);

    return () => {
      clearTimeout(showTimer);
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [phase, currentIndex, currentSpeed]);

  // Calculate results
  useEffect(() => {
    if (phase !== 'result') return;
    stopNoise();

    const channelResults: Record<string, ChannelResult> = {};
    let totalAcc = 0;

    for (const ch of activeChannels) {
      let hits = 0, misses = 0, falseAlarms = 0, correctRejections = 0;
      const resp = responses[ch] ?? new Set();

      for (let i = 0; i < sequence.length; i++) {
        const isMatch = sequence[i].matches.find(m => m.channel === ch)?.isMatch ?? false;
        const responded = resp.has(i);
        if (isMatch && responded) hits++;
        else if (isMatch && !responded) misses++;
        else if (!isMatch && responded) falseAlarms++;
        else correctRejections++;
      }

      const totalMatches = hits + misses;
      const hitRate = totalMatches > 0 ? hits / totalMatches : 0;
      const faPenalty = falseAlarms > 0 ? (falseAlarms / (falseAlarms + correctRejections)) * 0.5 : 0;
      const accuracy = Math.max(0, Math.min(100, (hitRate * 100) - (faPenalty * 30)));

      channelResults[ch] = { hits, misses, falseAlarms, correctRejections, accuracy };
      totalAcc += accuracy;
    }

    const avgAcc = activeChannels.length > 0 ? totalAcc / activeChannels.length : 0;
    setResults(channelResults);
    setTotalAccuracy(avgAcc);

    const duration = Math.round((Date.now() - startTime) / 1000);
    const xp = Math.round(avgAcc * 0.8 + advancedCore.n * 8 + activeChannels.length * 10);

    addSession({
      mode: 'advanced',
      date: new Date().toISOString(),
      accuracy: avgAcc,
      n: advancedCore.n,
      channels: activeChannels,
      hits: Object.values(channelResults).reduce((a, r) => a + r.hits, 0),
      misses: Object.values(channelResults).reduce((a, r) => a + r.misses, 0),
      falseAlarms: Object.values(channelResults).reduce((a, r) => a + r.falseAlarms, 0),
      correctRejections: Object.values(channelResults).reduce((a, r) => a + r.correctRejections, 0),
      xpEarned: xp,
      duration,
      channelDetails: channelResults,
    });
    addXP(xp);
  }, [phase]);

  const handleResponse = (channel: string) => {
    if (phase !== 'playing' || goNoGo) return;
    const cn = advancedTaskSwitching.multiChannelN
      ? (advancedTaskSwitching.channelNValues[channel] ?? currentN)
      : currentN;
    if (currentIndex < cn) return;
    if (responses[channel]?.has(currentIndex)) return;

    setResponses(prev => {
      const newSet = new Set(prev[channel]);
      newSet.add(currentIndex);
      return { ...prev, [channel]: newSet };
    });

    const isMatch = sequence[currentIndex]?.matches.find(m => m.channel === channel)?.isMatch ?? false;
    if (isMatch) {
      setFeedback({ type: 'correct', channel });
      if (settings.soundEnabled) playCorrectSound();
    } else {
      setFeedback({ type: 'wrong', channel });
      if (settings.soundEnabled) playWrongSound();
    }
    setTimeout(() => setFeedback({ type: null, channel: '' }), 300);
  };

  const togglePause = () => {
    if (phase === 'playing') {
      pauseRef.current = true;
      setPhase('paused');
      if (timerRef.current) clearTimeout(timerRef.current);
    } else if (phase === 'paused') {
      pauseRef.current = false;
      setPhase('playing');
      setCurrentIndex(prev => prev);
    }
  };

  const channelEmoji: Record<string, string> = {
    position: '📍', audio1: '🔊', audio2: '🎧', shape: '🔷', color: '🎨',
    vibration: '📳', size: '📐', texture: '🧵', visualNumber: '🔢', visualLetter: '🔤'
  };

  const channelLabel: Record<string, string> = {
    position: 'Pos', audio1: 'Aud1', audio2: 'Aud2', shape: 'Shape', color: 'Color',
    vibration: 'Vib', size: 'Size', texture: 'Tex', visualNumber: 'Num', visualLetter: 'Let'
  };

  if (phase === 'ready') {
    return (
      <div className={`h-full flex flex-col items-center justify-center ${dark ? 'bg-dark-bg text-dark-text' : 'bg-gray-50 text-gray-900'}`}>
        <div className={`w-24 h-24 rounded-3xl flex items-center justify-center bg-gradient-to-br from-neon-purple to-brand-500 mb-6 ${anims ? 'animate-pulse-glow' : ''}`}>
          <span className="text-5xl">⚡</span>
        </div>
        <h2 className="text-2xl font-black mb-2">Advanced {advancedCore.n}-Back</h2>
        <p className={`text-sm mb-1 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>{activeChannels.length} channels • {advancedCore.stimuliCount} stimuli</p>
        <p className={`text-xs mb-8 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>{activeChannels.map(c => channelEmoji[c]).join(' ')}</p>
        <button onClick={startGame} className="w-20 h-20 rounded-full bg-gradient-to-r from-neon-purple to-brand-500 flex items-center justify-center shadow-lg shadow-neon-purple/40 active:scale-95 transition-transform">
          <Play className="w-10 h-10 text-white ml-1" />
        </button>
        <button onClick={() => setScreen('advanced-settings')} className={`mt-6 text-sm ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>← Back to settings</button>
      </div>
    );
  }

  if (phase === 'result') {
    return (
      <div className={`h-full flex flex-col ${dark ? 'bg-dark-bg text-dark-text' : 'bg-gray-50 text-gray-900'}`}>
        <div className="px-5 pt-6 pb-4 flex items-center justify-between">
          <h1 className="text-xl font-bold">Results</h1>
          <button onClick={() => setScreen('advanced-settings')} className={`w-10 h-10 rounded-xl flex items-center justify-center ${dark ? 'bg-dark-surface' : 'bg-white shadow-sm'}`}>
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-5 pb-6 space-y-4">
          <div className={`rounded-3xl p-6 text-center ${dark ? 'bg-dark-card border border-dark-border' : 'bg-white shadow-sm'}`}>
            <p className={`text-xs uppercase tracking-wider mb-2 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Overall Accuracy</p>
            <p className={`text-6xl font-black ${totalAccuracy >= 80 ? 'text-green-400' : totalAccuracy >= 50 ? 'text-yellow-400' : 'text-red-400'}`}>
              {totalAccuracy.toFixed(1)}%
            </p>
          </div>

          {activeChannels.map(ch => {
            const r = results[ch];
            if (!r) return null;
            return (
              <div key={ch} className={`rounded-3xl p-5 ${dark ? 'bg-dark-card border border-dark-border' : 'bg-white shadow-sm'}`}>
                <h3 className="font-bold text-sm mb-3">{channelEmoji[ch]} {channelLabel[ch]}</h3>
                <div className="grid grid-cols-4 gap-2 mb-2">
                  <div className="text-center">
                    <p className="text-green-400 text-lg font-black">{r.hits}</p>
                    <p className={`text-[9px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Hits</p>
                  </div>
                  <div className="text-center">
                    <p className="text-red-400 text-lg font-black">{r.misses}</p>
                    <p className={`text-[9px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Miss</p>
                  </div>
                  <div className="text-center">
                    <p className="text-orange-400 text-lg font-black">{r.falseAlarms}</p>
                    <p className={`text-[9px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>FA</p>
                  </div>
                  <div className="text-center">
                    <p className="text-blue-400 text-lg font-black">{r.correctRejections}</p>
                    <p className={`text-[9px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>CR</p>
                  </div>
                </div>
                <div className={`h-2 rounded-full overflow-hidden ${dark ? 'bg-dark-border' : 'bg-gray-200'}`}>
                  <div className={`h-full rounded-full ${r.accuracy >= 80 ? 'bg-green-400' : r.accuracy >= 50 ? 'bg-yellow-400' : 'bg-red-400'}`} style={{ width: `${r.accuracy}%` }} />
                </div>
                <p className="text-right text-xs font-bold mt-1">{r.accuracy.toFixed(1)}%</p>
              </div>
            );
          })}

          <div className="flex gap-3">
            <button onClick={() => { generateGame(); setPhase('ready'); }} className="flex-1 py-3 rounded-2xl font-bold text-sm bg-gradient-to-r from-neon-purple to-brand-500 text-white">Again</button>
            <button onClick={() => setScreen('home')} className={`flex-1 py-3 rounded-2xl font-bold text-sm ${dark ? 'bg-dark-surface text-dark-text' : 'bg-gray-100 text-gray-700'}`}>Home</button>
          </div>
        </div>
      </div>
    );
  }

  // Playing screen
  const stim = sequence[currentIndex];
  const gridSize = advancedCore.gridSize;
  const position = stim?.stimulus.position ?? -1;
  const shapeIdx = stim?.stimulus.shape ?? 0;
  const colorIdx = stim?.stimulus.color ?? 0;
  const sizeVal = stim?.stimulus.size ?? 0;
  const textureVal = stim?.stimulus.texture ?? 0;
  const visNum = stim?.stimulus.visualNumber;
  const visLet = stim?.stimulus.visualLetter;

  const renderShape = (idx: number, size: string, color: string) => {
    const shapes: Record<string, string> = {
      circle: '●', square: '■', triangle: '▲', diamond: '◆', star: '★',
      hexagon: '⬡', pentagon: '⬠', cross: '✚', heart: '♥'
    };
    return <span style={{ color, fontSize: size }}>{shapes[SHAPES[idx]] || '●'}</span>;
  };

  const getTexture = (t: number) => {
    if (t === 1) return 'repeating-linear-gradient(0deg, transparent, transparent 3px, rgba(255,255,255,0.15) 3px, rgba(255,255,255,0.15) 4px)';
    if (t === 2) return 'repeating-linear-gradient(90deg, transparent, transparent 3px, rgba(255,255,255,0.15) 3px, rgba(255,255,255,0.15) 4px)';
    return 'none';
  };

  return (
    <div className={`h-full flex flex-col ${dark ? 'bg-dark-bg text-dark-text' : 'bg-gray-50 text-gray-900'}`} style={{ opacity }}>
      {/* Go/No-Go overlay */}
      {goNoGo && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-red-900/30 pointer-events-auto">
          <div className="bg-red-500/90 px-6 py-3 rounded-2xl flex items-center gap-2">
            <Lock className="w-5 h-5 text-white" />
            <span className="text-white font-bold text-sm">NO-GO</span>
          </div>
        </div>
      )}

      {/* Paused overlay */}
      {phase === 'paused' && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/70">
          <div className="text-center">
            <p className="text-3xl font-black text-white mb-4">⏸ Paused</p>
            <button onClick={togglePause} className="px-8 py-3 rounded-2xl bg-gradient-to-r from-neon-purple to-brand-500 text-white font-bold">Resume</button>
          </div>
        </div>
      )}

      {/* Top bar */}
      <div className="px-4 pt-3 pb-1 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className={`text-xs font-bold px-2 py-1 rounded-lg ${dark ? 'bg-neon-purple/20 text-neon-purple' : 'bg-brand-50 text-brand-600'}`}>
            N={currentN}
          </span>
          <span className={`text-[10px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>
            {currentIndex + 1}/{sequence.length} • {currentSpeed}ms
          </span>
        </div>
        <div className="flex gap-1">
          <button onClick={togglePause} className={`w-8 h-8 rounded-lg flex items-center justify-center ${dark ? 'bg-dark-surface' : 'bg-white shadow-sm'}`}>
            {phase === 'paused' ? <Play className="w-3 h-3" /> : <Pause className="w-3 h-3" />}
          </button>
          <button onClick={() => { stopNoise(); setScreen('advanced-settings'); }} className={`w-8 h-8 rounded-lg flex items-center justify-center ${dark ? 'bg-dark-surface' : 'bg-white shadow-sm'}`}>
            <X className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Progress */}
      <div className="px-4 pb-1">
        <div className={`w-full h-1 rounded-full overflow-hidden ${dark ? 'bg-dark-border' : 'bg-gray-200'}`}>
          <div className="h-full rounded-full bg-gradient-to-r from-neon-purple to-brand-500 transition-all duration-300" style={{ width: `${((currentIndex + 1) / sequence.length) * 100}%` }} />
        </div>
      </div>

      {/* Grid area */}
      <div className="flex-1 flex items-center justify-center px-4 relative">
        {/* Visual noise overlay */}
        {visualNoise && (
          <div className="absolute inset-0 z-10 pointer-events-none opacity-40"
            style={{
              background: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`,
            }}
          />
        )}

        <div
          className="w-full max-w-[300px] aspect-square grid gap-1"
          style={{
            gridTemplateColumns: `repeat(${gridSize}, 1fr)`,
            opacity: advancedInterference.fadingEnabled ? fadingOpacity : 1,
            transition: advancedInterference.fadingEnabled ? `opacity ${currentSpeed * 0.5}ms ease-out` : 'none',
          }}
        >
          {Array.from({ length: gridSize * gridSize }, (_, i) => {
            const isActive = showStimulus && position === i;
            const cellColor = advancedCore.channels.color ? COLORS[colorIdx] : (dark ? '#6366f1' : '#4f46e5');

            return (
              <div
                key={i}
                className={`rounded-xl flex items-center justify-center relative overflow-hidden ${anims ? 'transition-all duration-150' : ''} ${
                  isActive
                    ? 'shadow-lg scale-95'
                    : dark ? 'bg-dark-surface/50 border border-dark-border/50' : 'bg-gray-100/50 border border-gray-200/50'
                }`}
                style={isActive ? {
                  backgroundColor: advancedCore.channels.color ? cellColor + '30' : (dark ? 'rgba(99,102,241,0.2)' : 'rgba(79,70,229,0.15)'),
                  borderColor: cellColor,
                  borderWidth: 2,
                  backgroundImage: advancedCore.channels.texture ? getTexture(textureVal) : 'none',
                  animation: (advancedCore.channels.vibration && stim?.stimulus.vibration) ? 'shake 0.1s infinite' : 'none',
                } : undefined}
              >
                {isActive && (
                  <div className="flex flex-col items-center justify-center gap-0.5">
                    {advancedCore.channels.shape && renderShape(shapeIdx, sizeVal === 1 ? '28px' : '18px', cellColor)}
                    <div className="flex gap-0.5">
                      {visLet !== undefined && <span className="text-xs font-bold" style={{ color: cellColor }}>{getAlphabetLetter(visLet)}</span>}
                      {visNum !== undefined && <span className="text-xs font-bold" style={{ color: cellColor }}>{visNum}</span>}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Response buttons */}
      <div className="px-3 pb-6 pt-2">
        <div className="h-5 flex items-center justify-center mb-2">
          {feedback.type && (
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${feedback.type === 'correct' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
              {feedback.type === 'correct' ? '✓' : '✗'} {feedback.channel}
            </span>
          )}
        </div>
        <div className="flex flex-wrap gap-2 justify-center">
          {activeChannels.filter(ch => activeButtons.has(ch)).map(ch => (
            <button
              key={ch}
              onClick={() => handleResponse(ch)}
              disabled={phase !== 'playing' || responses[ch]?.has(currentIndex)}
              className={`px-3 py-3 rounded-xl font-bold text-xs min-w-[60px] ${anims ? 'transition-all duration-100 active:scale-90' : ''} disabled:opacity-30 ${
                responses[ch]?.has(currentIndex)
                  ? dark ? 'bg-brand-500/30 text-brand-300' : 'bg-brand-100 text-brand-500'
                  : dark ? 'bg-dark-surface border border-dark-border text-dark-text hover:bg-dark-border' : 'bg-white border border-gray-200 text-gray-700 shadow-sm'
              }`}
            >
              {channelEmoji[ch]}<br />{channelLabel[ch]}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
