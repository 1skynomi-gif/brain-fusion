let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    audioCtx = new AudioContext();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

const PIANO_FREQS = [261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 493.88, 523.25, 587.33];
const LETTER_SOUNDS = ['C', 'H', 'K', 'L', 'Q', 'R', 'S', 'T', 'B', 'D', 'F', 'G', 'M', 'N', 'P'];
const NUMBER_SOUNDS = Array.from({ length: 20 }, (_, i) => i + 1);

export function playPianoNote(index: number, duration: number = 400, pan: number = 0) {
  const ctx = getAudioContext();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  const panner = ctx.createStereoPanner();
  
  osc.type = 'sine';
  osc.frequency.value = PIANO_FREQS[index % PIANO_FREQS.length];
  
  gain.gain.setValueAtTime(0.3, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + duration / 1000);
  
  panner.pan.value = pan;
  
  osc.connect(gain);
  gain.connect(panner);
  panner.connect(ctx.destination);
  
  osc.start();
  osc.stop(ctx.currentTime + duration / 1000);
}

export function speakLetter(letter: string, rate: number = 1.0) {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(letter);
    u.rate = Math.max(0.5, Math.min(rate, 3));
    u.volume = 0.8;
    u.pitch = 1;
    window.speechSynthesis.speak(u);
  }
}

export function speakNumber(num: number, rate: number = 1.0) {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(String(num));
    u.rate = Math.max(0.5, Math.min(rate, 3));
    u.volume = 0.8;
    window.speechSynthesis.speak(u);
  }
}

export function speakWord(word: string, rate: number = 1.0) {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(word);
    u.rate = Math.max(0.5, Math.min(rate, 3));
    u.volume = 0.8;
    window.speechSynthesis.speak(u);
  }
}

export function playCorrectSound() {
  const ctx = getAudioContext();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = 'sine';
  osc.frequency.value = 880;
  gain.gain.setValueAtTime(0.15, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start();
  osc.stop(ctx.currentTime + 0.2);
}

export function playWrongSound() {
  const ctx = getAudioContext();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = 'square';
  osc.frequency.value = 200;
  gain.gain.setValueAtTime(0.12, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start();
  osc.stop(ctx.currentTime + 0.3);
}

let noiseNode: AudioBufferSourceNode | null = null;
let noiseGain: GainNode | null = null;

export function startNoise(type: 'pink' | 'brown', intensity: number) {
  stopNoise();
  const ctx = getAudioContext();
  const bufferSize = ctx.sampleRate * 2;
  const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const data = buffer.getChannelData(0);

  if (type === 'pink') {
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      b3 = 0.86650 * b3 + white * 0.3104856;
      b4 = 0.55000 * b4 + white * 0.5329522;
      b5 = -0.7616 * b5 - white * 0.0168980;
      data[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.11;
      b6 = white * 0.115926;
    }
  } else {
    let lastOut = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      data[i] = (lastOut + (0.02 * white)) / 1.02;
      lastOut = data[i];
      data[i] *= 3.5;
    }
  }

  noiseNode = ctx.createBufferSource();
  noiseNode.buffer = buffer;
  noiseNode.loop = true;
  noiseGain = ctx.createGain();
  noiseGain.gain.value = (intensity / 10) * 0.5;
  noiseNode.connect(noiseGain);
  noiseGain.connect(ctx.destination);
  noiseNode.start();
}

export function stopNoise() {
  if (noiseNode) {
    try { noiseNode.stop(); } catch (e) { console.log(e); }
    noiseNode = null;
  }
  noiseGain = null;
}

export { LETTER_SOUNDS, NUMBER_SOUNDS, PIANO_FREQS };
