import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type GameMode = 'classic' | 'advanced' | 'arithmetic' | 'alien';
export type ThemeMode = 'dark' | 'light';

export interface ProfileData {
  name: string;
  level: number;
  xp: number;
  xpToNext: number;
  title: string;
  totalSessions: number;
  totalCorrect: number;
  bestAccuracy: number;
  streak: number;
  joinDate: string;
}

export interface SessionResult {
  mode: GameMode;
  date: string;
  accuracy: number;
  n: number;
  channels: string[];
  hits: number;
  misses: number;
  falseAlarms: number;
  correctRejections: number;
  xpEarned: number;
  duration: number;
  channelDetails: Record<string, { hits: number; misses: number; falseAlarms: number; correctRejections: number; accuracy: number }>;
}

export interface ClassicSettings {
  n: number;
  speed: number;
  stimuliCount: number;
  matchPercent: number;
  adaptiveEnabled: boolean;
  adaptiveThreshold: number;
  consecutiveGood: number;
  consecutiveBad: number;
}

export interface AdvancedCoreSettings {
  n: number;
  speed: number;
  stimuliCount: number;
  matchPercent: number;
  gridSize: number;
  adaptiveEnabled: boolean;
  adaptiveThreshold: number;
  adaptivePriority: 'speed' | 'channels' | 'n';
  channels: {
    position: boolean;
    shape: boolean;
    color: boolean;
    audio1: boolean;
    audio1Type: ('piano' | 'letters' | 'numbers')[];
    audio2: boolean;
    audio2Type: ('piano' | 'letters' | 'numbers')[];
    vibration: boolean;
    size: boolean;
    texture: boolean;
    visualNumbers: boolean;
    visualLetters: boolean;
  };
}

export interface InterferenceSettings {
  lureTrials: number;
  fadingEnabled: boolean;
  fadingIntensity: number;
  noiseType: 'none' | 'pink' | 'brown';
  noiseIntensity: number;
  opacityEnabled: boolean;
  opacityIntensity: number;
  goNoGoEnabled: boolean;
  goNoGoIntensity: number;
  visualNoiseEnabled: boolean;
  visualNoiseIntensity: number;
}

export interface TaskSwitchingSettings {
  dynamicN: boolean;
  dynamicNMin: number;
  dynamicNMax: number;
  dynamicNIntensity: number;
  multiChannelN: boolean;
  channelNValues: Record<string, number>;
  channelNDynamic: Record<string, boolean>;
  channelNDynamicMin: Record<string, number>;
  channelNDynamicMax: Record<string, number>;
  channelNDynamicIntensity: Record<string, number>;
  dynamicSpeed: boolean;
  dynamicSpeedMin: number;
  dynamicSpeedMax: number;
  dynamicSpeedIntensity: number;
  channelSwitching: boolean;
  channelSwitchingIntensity: number;
}

export interface ArithmeticSettings {
  n: number;
  speed: number;
  stimuliCount: number;
  matchPercent: number;
  gridSize: number;
  adaptiveEnabled: boolean;
  adaptiveThreshold: number;
  channels: {
    position: boolean;
    arithmetic: boolean;
    comparison: boolean;
    shape: boolean;
    color: boolean;
  };
  taskSwitching: {
    dynamicN: boolean;
    dynamicNMin: number;
    dynamicNMax: number;
    dynamicNIntensity: number;
    multiChannelN: boolean;
    channelNValues: Record<string, number>;
    dynamicSpeed: boolean;
    dynamicSpeedMin: number;
    dynamicSpeedMax: number;
    dynamicSpeedIntensity: number;
  };
}

export interface AlienSettings {
  stimuliCount: number;
  matchPercent: number;
  channels: {
    audio: boolean;
    audioType: ('piano' | 'letters' | 'numbers')[];
    position: boolean;
    gridSize: number;
    color: boolean;
    shape: boolean;
  };
  channelN: Record<string, number>;
  channelSpeed: Record<string, number>;
  interference: {
    lureTrials: number;
    noiseType: 'none' | 'pink' | 'brown';
    noiseIntensity: number;
    visualNoiseEnabled: boolean;
    visualNoiseIntensity: number;
    opacityEnabled: boolean;
    opacityIntensity: number;
  };
  taskSwitching: TaskSwitchingSettings;
}

export interface AppSettings {
  theme: ThemeMode;
  animationsEnabled: boolean;
  particleEffects: boolean;
  transitionEffects: boolean;
  hapticFeedback: boolean;
  soundEnabled: boolean;
}

interface AppState {
  currentScreen: string;
  settings: AppSettings;
  profile: ProfileData;
  sessionHistory: SessionResult[];
  classicSettings: ClassicSettings;
  advancedCore: AdvancedCoreSettings;
  advancedInterference: InterferenceSettings;
  advancedTaskSwitching: TaskSwitchingSettings;
  arithmeticSettings: ArithmeticSettings;
  alienSettings: AlienSettings;
  setScreen: (s: string) => void;
  setSettings: (s: Partial<AppSettings>) => void;
  setProfile: (p: Partial<ProfileData>) => void;
  addSession: (r: SessionResult) => void;
  setClassicSettings: (s: Partial<ClassicSettings>) => void;
  setAdvancedCore: (s: Partial<AdvancedCoreSettings>) => void;
  setAdvancedInterference: (s: Partial<InterferenceSettings>) => void;
  setAdvancedTaskSwitching: (s: Partial<TaskSwitchingSettings>) => void;
  setArithmeticSettings: (s: Partial<ArithmeticSettings>) => void;
  setAlienSettings: (s: Partial<AlienSettings>) => void;
  addXP: (amount: number) => void;
}

const TITLES: [number, string][] = [
  [1, 'Novice Mind'],
  [5, 'Apprentice Thinker'],
  [10, 'Cognitive Explorer'],
  [15, 'Neural Pathfinder'],
  [20, 'Synapse Warrior'],
  [25, 'Cortex Commander'],
  [30, 'Memory Architect'],
  [35, 'Neural Titan'],
  [40, 'Quantum Thinker'],
  [45, 'Brain Overlord'],
  [50, 'Cognitive Maestro'],
  [60, 'Neural Sovereign'],
  [70, 'Mind Dimension Master'],
  [80, 'Cerebral Ascendant'],
  [90, 'Omega Brain'],
  [100, 'Transcendent Mind'],
];

function getTitleForLevel(level: number): string {
  let title = 'Novice Mind';
  for (const [req, t] of TITLES) {
    if (level >= req) title = t;
  }
  return title;
}

function xpForLevel(level: number): number {
  return Math.floor(100 * Math.pow(1.25, level - 1));
}

export const useStore = create<AppState>()(
  persist(
    (set) => ({
      currentScreen: 'home',
      settings: {
        theme: 'dark',
        animationsEnabled: true,
        particleEffects: true,
        transitionEffects: true,
        hapticFeedback: true,
        soundEnabled: true,
      },
      profile: {
        name: 'Player',
        level: 1,
        xp: 0,
        xpToNext: 100,
        title: 'Novice Mind',
        totalSessions: 0,
        totalCorrect: 0,
        bestAccuracy: 0,
        streak: 0,
        joinDate: new Date().toISOString(),
      },
      sessionHistory: [],
      classicSettings: {
        n: 2,
        speed: 2500,
        stimuliCount: 25,
        matchPercent: 25,
        adaptiveEnabled: false,
        adaptiveThreshold: 80,
        consecutiveGood: 0,
        consecutiveBad: 0,
      },
      advancedCore: {
        n: 2,
        speed: 2500,
        stimuliCount: 30,
        matchPercent: 25,
        gridSize: 3,
        adaptiveEnabled: false,
        adaptiveThreshold: 80,
        adaptivePriority: 'n',
        channels: {
          position: true,
          shape: false,
          color: false,
          audio1: true,
          audio1Type: ['letters'],
          audio2: false,
          audio2Type: ['piano'],
          vibration: false,
          size: false,
          texture: false,
          visualNumbers: false,
          visualLetters: false,
        },
      },
      advancedInterference: {
        lureTrials: 10,
        fadingEnabled: false,
        fadingIntensity: 5,
        noiseType: 'none',
        noiseIntensity: 5,
        opacityEnabled: false,
        opacityIntensity: 5,
        goNoGoEnabled: false,
        goNoGoIntensity: 5,
        visualNoiseEnabled: false,
        visualNoiseIntensity: 5,
      },
      advancedTaskSwitching: {
        dynamicN: false,
        dynamicNMin: 1,
        dynamicNMax: 5,
        dynamicNIntensity: 5,
        multiChannelN: false,
        channelNValues: {},
        channelNDynamic: {},
        channelNDynamicMin: {},
        channelNDynamicMax: {},
        channelNDynamicIntensity: {},
        dynamicSpeed: false,
        dynamicSpeedMin: 1000,
        dynamicSpeedMax: 5000,
        dynamicSpeedIntensity: 5,
        channelSwitching: false,
        channelSwitchingIntensity: 5,
      },
      arithmeticSettings: {
        n: 2,
        speed: 5000,
        stimuliCount: 25,
        matchPercent: 25,
        gridSize: 3,
        adaptiveEnabled: false,
        adaptiveThreshold: 80,
        channels: {
          position: true,
          arithmetic: true,
          comparison: false,
          shape: false,
          color: false,
        },
        taskSwitching: {
          dynamicN: false,
          dynamicNMin: 1,
          dynamicNMax: 5,
          dynamicNIntensity: 5,
          multiChannelN: false,
          channelNValues: {},
          dynamicSpeed: false,
          dynamicSpeedMin: 1000,
          dynamicSpeedMax: 10000,
          dynamicSpeedIntensity: 5,
        },
      },
      alienSettings: {
        stimuliCount: 30,
        matchPercent: 25,
        channels: {
          audio: true,
          audioType: ['letters'],
          position: true,
          gridSize: 3,
          color: false,
          shape: false,
        },
        channelN: { audio: 2, position: 2, color: 2, shape: 2 },
        channelSpeed: { audio: 2500, position: 2500, color: 2500, shape: 2500 },
        interference: {
          lureTrials: 10,
          noiseType: 'none',
          noiseIntensity: 5,
          visualNoiseEnabled: false,
          visualNoiseIntensity: 5,
          opacityEnabled: false,
          opacityIntensity: 5,
        },
        taskSwitching: {
          dynamicN: false,
          dynamicNMin: 1,
          dynamicNMax: 5,
          dynamicNIntensity: 5,
          multiChannelN: false,
          channelNValues: {},
          channelNDynamic: {},
          channelNDynamicMin: {},
          channelNDynamicMax: {},
          channelNDynamicIntensity: {},
          dynamicSpeed: false,
          dynamicSpeedMin: 1000,
          dynamicSpeedMax: 5000,
          dynamicSpeedIntensity: 5,
          channelSwitching: false,
          channelSwitchingIntensity: 5,
        },
      },
      setScreen: (s) => set({ currentScreen: s }),
      setSettings: (s) => set((state) => ({ settings: { ...state.settings, ...s } })),
      setProfile: (p) => set((state) => ({ profile: { ...state.profile, ...p } })),
      addSession: (r) => set((state) => ({
        sessionHistory: [...state.sessionHistory, r],
        profile: {
          ...state.profile,
          totalSessions: state.profile.totalSessions + 1,
          totalCorrect: state.profile.totalCorrect + r.hits,
          bestAccuracy: Math.max(state.profile.bestAccuracy, r.accuracy),
        },
      })),
      setClassicSettings: (s) => set((state) => ({ classicSettings: { ...state.classicSettings, ...s } })),
      setAdvancedCore: (s) => set((state) => ({ advancedCore: { ...state.advancedCore, ...s } })),
      setAdvancedInterference: (s) => set((state) => ({ advancedInterference: { ...state.advancedInterference, ...s } })),
      setAdvancedTaskSwitching: (s) => set((state) => ({ advancedTaskSwitching: { ...state.advancedTaskSwitching, ...s } })),
      setArithmeticSettings: (s) => set((state) => ({ arithmeticSettings: { ...state.arithmeticSettings, ...s } })),
      setAlienSettings: (s) => set((state) => ({ alienSettings: { ...state.alienSettings, ...s } })),
      addXP: (amount) => set((state) => {
        let xp = state.profile.xp + amount;
        let level = state.profile.level;
        let xpToNext = xpForLevel(level);
        while (xp >= xpToNext) {
          xp -= xpToNext;
          level++;
          xpToNext = xpForLevel(level);
        }
        return {
          profile: {
            ...state.profile,
            xp,
            level,
            xpToNext,
            title: getTitleForLevel(level),
          },
        };
      }),
    }),
    {
      name: 'brain-fusion-storage',
      partialize: (state) => ({
        settings: state.settings,
        profile: state.profile,
        sessionHistory: state.sessionHistory,
        classicSettings: state.classicSettings,
        advancedCore: state.advancedCore,
        advancedInterference: state.advancedInterference,
        advancedTaskSwitching: state.advancedTaskSwitching,
        arithmeticSettings: state.arithmeticSettings,
        alienSettings: state.alienSettings,
      }),
    }
  )
);
