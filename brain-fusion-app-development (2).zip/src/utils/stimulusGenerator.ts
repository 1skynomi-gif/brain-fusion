import { LETTER_SOUNDS } from './audio';

export interface Stimulus {
  position?: number;
  audio1?: number;
  audio2?: number;
  shape?: number;
  color?: number;
  size?: number;
  texture?: number;
  visualNumber?: number;
  visualLetter?: number;
  vibration?: boolean;
  arithmeticOp?: 'add' | 'subtract' | 'multiply';
  arithmeticNum?: number;
  comparisonNum?: number;
}

export interface ChannelMatch {
  channel: string;
  isMatch: boolean;
  isLure: boolean;
}

export interface GeneratedStimulus {
  stimulus: Stimulus;
  matches: ChannelMatch[];
}

const SHAPES = ['circle', 'square', 'triangle', 'diamond', 'star', 'hexagon', 'pentagon', 'cross', 'heart'];
const COLORS = ['#ef4444', '#3b82f6', '#22c55e', '#eab308', '#a855f7', '#f97316'];

export { SHAPES, COLORS };

interface GeneratorOptions {
  n: number;
  totalStimuli: number;
  matchPercent: number;
  channels: string[];
  gridSize?: number;
  lurePercent?: number;
  channelN?: Record<string, number>;
}

function randInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function getChannelRange(channel: string, gridSize: number = 3): number {
  switch (channel) {
    case 'position': return gridSize * gridSize;
    case 'audio1':
    case 'audio2': return 9;
    case 'shape': return SHAPES.length;
    case 'color': return COLORS.length;
    case 'size': return 2;
    case 'texture': return 3;
    case 'visualNumber': return 9;
    case 'visualLetter': return 26;
    case 'vibration': return 2;
    case 'arithmeticNum': return 99;
    case 'comparisonNum': return 99;
    default: return 9;
  }
}

function getDifferentValue(current: number, range: number): number {
  if (range <= 1) return 0;
  let v: number;
  do {
    v = randInt(0, range - 1);
  } while (v === current);
  return v;
}

export function generateSequence(options: GeneratorOptions): GeneratedStimulus[] {
  const { n, totalStimuli, matchPercent, channels, gridSize = 3, lurePercent = 0, channelN } = options;

  const matchCountPerChannel = Math.round((totalStimuli * matchPercent) / 100);
  const lureCountPerChannel = Math.round((totalStimuli * lurePercent) / 100);

  // For each channel, decide which positions are matches
  const channelMatchPositions: Record<string, Set<number>> = {};
  const channelLurePositions: Record<string, Set<number>> = {};

  for (const ch of channels) {
    const cn = channelN?.[ch] ?? n;
    const available: number[] = [];
    for (let i = cn; i < totalStimuli; i++) available.push(i);

    // Shuffle and pick match positions
    const shuffled = [...available].sort(() => Math.random() - 0.5);
    const matchPositions = new Set(shuffled.slice(0, Math.min(matchCountPerChannel, shuffled.length)));
    channelMatchPositions[ch] = matchPositions;

    // Pick lure positions (n+1 or n-1 matches, not already a match)
    const remainingForLure = shuffled.filter(i => !matchPositions.has(i));
    const lurePicks = remainingForLure.slice(0, Math.min(lureCountPerChannel, remainingForLure.length));
    channelLurePositions[ch] = new Set(lurePicks);
  }

  // Generate the sequence
  const sequence: GeneratedStimulus[] = [];

  // Initialize with random values
  const channelValues: Record<string, number[]> = {};
  for (const ch of channels) {
    channelValues[ch] = [];
  }

  for (let i = 0; i < totalStimuli; i++) {
    const stimulus: Stimulus = {};
    const matches: ChannelMatch[] = [];

    for (const ch of channels) {
      const cn = channelN?.[ch] ?? n;
      const range = getChannelRange(ch, gridSize);
      let value: number;
      let isMatch = false;
      let isLure = false;

      if (i >= cn && channelMatchPositions[ch].has(i)) {
        // This should be a match with n-back
        value = channelValues[ch][i - cn];
        isMatch = true;
      } else if (i >= cn && channelLurePositions[ch].has(i)) {
        // Lure: match with n-1 or n+1 back
        const lureN = Math.random() > 0.5 ? cn - 1 : cn + 1;
        if (lureN > 0 && i - lureN >= 0) {
          value = channelValues[ch][i - lureN];
          // Make sure it's not accidentally also a real match
          if (i >= cn && channelValues[ch][i - cn] === value) {
            value = getDifferentValue(channelValues[ch][i - cn], range);
          }
        } else {
          value = randInt(0, range - 1);
        }
        isLure = true;
      } else {
        // Non-match: ensure it doesn't accidentally match
        value = randInt(0, range - 1);
        if (i >= cn && value === channelValues[ch][i - cn]) {
          value = getDifferentValue(value, range);
        }
      }

      channelValues[ch].push(value);

      // Assign to stimulus
      switch (ch) {
        case 'position': stimulus.position = value; break;
        case 'audio1': stimulus.audio1 = value; break;
        case 'audio2': stimulus.audio2 = value; break;
        case 'shape': stimulus.shape = value; break;
        case 'color': stimulus.color = value; break;
        case 'size': stimulus.size = value; break;
        case 'texture': stimulus.texture = value; break;
        case 'visualNumber': stimulus.visualNumber = value + 1; break;
        case 'visualLetter': stimulus.visualLetter = value; break;
        case 'vibration': stimulus.vibration = value === 1; break;
        case 'arithmeticNum': stimulus.arithmeticNum = value + 1; break;
        case 'comparisonNum': stimulus.comparisonNum = value + 1; break;
      }

      matches.push({ channel: ch, isMatch, isLure });
    }

    sequence.push({ stimulus, matches });
  }

  return sequence;
}

export function generateArithmeticSequence(options: {
  n: number;
  totalStimuli: number;
  matchPercent: number;
  gridSize: number;
  channels: string[];
  channelN?: Record<string, number>;
}): GeneratedStimulus[] {
  const { n, totalStimuli, channels, gridSize, channelN } = options;

  const sequence: GeneratedStimulus[] = [];
  const ops: ('add' | 'subtract' | 'multiply')[] = ['add', 'subtract', 'multiply'];
  const numbers: number[] = [];
  const positions: number[] = [];

  for (let i = 0; i < totalStimuli; i++) {
    const stimulus: Stimulus = {};
    const matches: ChannelMatch[] = [];

    // Generate number
    const num = randInt(1, 99);
    numbers.push(num);
    stimulus.arithmeticNum = num;

    // Generate operation
    const op = ops[randInt(0, 2)];
    stimulus.arithmeticOp = op;

    // Make sure subtraction doesn't go negative
    if (op === 'subtract' && i >= (channelN?.['arithmetic'] ?? n)) {
      const prevNum = numbers[i - (channelN?.['arithmetic'] ?? n)];
      if (num > prevNum) {
        stimulus.arithmeticNum = randInt(1, prevNum);
        numbers[i] = stimulus.arithmeticNum;
      }
    }

    // Position
    if (channels.includes('position')) {
      const pos = randInt(0, gridSize * gridSize - 1);
      positions.push(pos);
      stimulus.position = pos;
      const cn = channelN?.['position'] ?? n;
      if (i >= cn) {
        matches.push({ channel: 'position', isMatch: pos === positions[i - cn], isLure: false });
      }
    }

    if (channels.includes('arithmetic')) {
      matches.push({ channel: 'arithmetic', isMatch: false, isLure: false });
    }

    if (channels.includes('comparison')) {
      stimulus.comparisonNum = num;
      matches.push({ channel: 'comparison', isMatch: false, isLure: false });
    }

    sequence.push({ stimulus, matches });
  }

  return sequence;
}

export function getLetterForIndex(index: number): string {
  return LETTER_SOUNDS[index % LETTER_SOUNDS.length];
}

export function getAlphabetLetter(index: number): string {
  return String.fromCharCode(65 + (index % 26));
}
