import { useState } from 'react';
import { useStore } from '../../store/useStore';
import { Card } from '../ui/Card';
import { Slider } from '../ui/Slider';
import { Toggle } from '../ui/Toggle';
import { Button } from '../ui/Button';
import { ArrowLeft, Play, Skull } from 'lucide-react';

export function AlienSettingsScreen() {
  const { settings, alienSettings, setAlienSettings, setScreen } = useStore();
  const dark = settings.theme === 'dark';
  const [tab, setTab] = useState<'core' | 'interference' | 'taskSwitch'>('core');

  const activeChannels: string[] = [];
  if (alienSettings.channels.position) activeChannels.push('position');
  if (alienSettings.channels.audio) activeChannels.push('audio');
  if (alienSettings.channels.color) activeChannels.push('color');
  if (alienSettings.channels.shape) activeChannels.push('shape');

  return (
    <div className={`h-full flex flex-col ${dark ? 'bg-dark-bg text-dark-text' : 'bg-gray-50 text-gray-900'}`}>
      <div className="px-5 pt-6 pb-2 flex items-center gap-3">
        <button onClick={() => setScreen('home')} className={`w-10 h-10 rounded-xl flex items-center justify-center ${dark ? 'bg-dark-surface' : 'bg-white shadow-sm'}`}>
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex-1">
          <h1 className="text-xl font-bold">Alien Mode</h1>
          <p className={`text-xs ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Multi-speed independent channels</p>
        </div>
        <Skull className={`w-6 h-6 ${dark ? 'text-neon-pink' : 'text-red-500'}`} />
      </div>

      <div className="px-5 py-2 flex gap-2">
        {[
          { id: 'core' as const, label: '⚙️ Core' },
          { id: 'interference' as const, label: '🌀 Interf.' },
          { id: 'taskSwitch' as const, label: '🔀 Switch' },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
              tab === t.id ? 'bg-gradient-to-r from-neon-pink to-red-600 text-white'
                : dark ? 'bg-dark-surface text-dark-muted' : 'bg-gray-100 text-gray-500'
            }`}
          >{t.label}</button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-6 space-y-4">
        {tab === 'core' && (
          <>
            <Card>
              <h3 className="font-bold text-sm mb-4">Session</h3>
              <div className="space-y-5">
                <Slider label="Stimuli (average)" value={alienSettings.stimuliCount} min={25} max={10000} step={5} onChange={v => setAlienSettings({ stimuliCount: v })} />
                <Slider label="Match %" value={alienSettings.matchPercent} min={10} max={40} step={5} onChange={v => setAlienSettings({ matchPercent: v })} unit="%" />
              </div>
            </Card>

            <Card>
              <h3 className="font-bold text-sm mb-4">Channels</h3>
              <div className="space-y-3">
                <Toggle label="📍 Position" value={alienSettings.channels.position} onChange={v => setAlienSettings({ channels: { ...alienSettings.channels, position: v } })} />
                {alienSettings.channels.position && (
                  <Slider label="Grid Size" value={alienSettings.channels.gridSize} min={3} max={9} onChange={v => setAlienSettings({ channels: { ...alienSettings.channels, gridSize: v } })} formatValue={v => `${v}×${v}`} />
                )}

                <Toggle label="🔊 Audio" value={alienSettings.channels.audio} onChange={v => setAlienSettings({ channels: { ...alienSettings.channels, audio: v } })} />
                {alienSettings.channels.audio && (
                  <div className="ml-4 space-y-1">
                    {(['piano', 'letters', 'numbers'] as const).map(type => (
                      <label key={type} className="flex items-center gap-2 text-xs">
                        <input type="checkbox"
                          checked={alienSettings.channels.audioType.includes(type)}
                          onChange={e => {
                            const types = e.target.checked
                              ? [...alienSettings.channels.audioType, type]
                              : alienSettings.channels.audioType.filter(t => t !== type);
                            setAlienSettings({ channels: { ...alienSettings.channels, audioType: types.length ? types : ['letters'] } });
                          }} />
                        {type === 'piano' ? '🎹 Piano' : type === 'letters' ? '🔤 Letters' : '🔢 Numbers'}
                      </label>
                    ))}
                  </div>
                )}

                <Toggle label="🎨 Color" value={alienSettings.channels.color} onChange={v => setAlienSettings({ channels: { ...alienSettings.channels, color: v } })} />
                <Toggle label="🔷 Shape" value={alienSettings.channels.shape} onChange={v => setAlienSettings({ channels: { ...alienSettings.channels, shape: v } })} />
              </div>
            </Card>

            <Card>
              <h3 className="font-bold text-sm mb-4">Per-Channel N & Speed</h3>
              <p className={`text-[10px] mb-3 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>
                Each channel runs independently with its own N and speed. Stimuli counts auto-balance.
              </p>
              {activeChannels.map(ch => (
                <div key={ch} className={`p-3 rounded-xl mb-3 ${dark ? 'bg-dark-surface' : 'bg-gray-50'}`}>
                  <p className="text-xs font-bold mb-2">
                    {ch === 'position' ? '📍' : ch === 'audio' ? '🔊' : ch === 'color' ? '🎨' : '🔷'} {ch}
                  </p>
                  <Slider label="N" value={alienSettings.channelN[ch] ?? 2} min={1} max={100} onChange={v => setAlienSettings({ channelN: { ...alienSettings.channelN, [ch]: v } })} />
                  <div className="mt-3">
                    <Slider label="Speed" value={alienSettings.channelSpeed[ch] ?? 2500} min={100} max={20000} step={100} onChange={v => setAlienSettings({ channelSpeed: { ...alienSettings.channelSpeed, [ch]: v } })} unit="ms" formatValue={v => v >= 1000 ? `${(v/1000).toFixed(1)}s` : `${v}ms`} />
                  </div>
                </div>
              ))}
            </Card>
          </>
        )}

        {tab === 'interference' && (
          <>
            <Card>
              <h3 className="font-bold text-sm mb-4">Lure Trials</h3>
              <Slider label="Lure %" value={alienSettings.interference.lureTrials} min={10} max={100} step={10} onChange={v => setAlienSettings({ interference: { ...alienSettings.interference, lureTrials: v } })} unit="%" />
            </Card>

            <Card>
              <h3 className="font-bold text-sm mb-4">Audio Noise</h3>
              <div className="flex gap-2 mb-3">
                {(['none', 'pink', 'brown'] as const).map(type => (
                  <button key={type} onClick={() => setAlienSettings({ interference: { ...alienSettings.interference, noiseType: type } })}
                    className={`flex-1 py-2 rounded-xl text-xs font-bold ${
                      alienSettings.interference.noiseType === type
                        ? 'bg-gradient-to-r from-neon-pink to-red-600 text-white'
                        : dark ? 'bg-dark-surface text-dark-muted' : 'bg-gray-100 text-gray-500'
                    }`}>{type === 'none' ? 'Off' : type === 'pink' ? '🩷 Pink' : '🤎 Brown'}</button>
                ))}
              </div>
              {alienSettings.interference.noiseType !== 'none' && (
                <Slider label="Intensity" value={alienSettings.interference.noiseIntensity} min={1} max={10} onChange={v => setAlienSettings({ interference: { ...alienSettings.interference, noiseIntensity: v } })} />
              )}
            </Card>

            <Card>
              <h3 className="font-bold text-sm mb-4">Visual Effects</h3>
              <Toggle label="Pixel Noise" value={alienSettings.interference.visualNoiseEnabled} onChange={v => setAlienSettings({ interference: { ...alienSettings.interference, visualNoiseEnabled: v } })} />
              {alienSettings.interference.visualNoiseEnabled && (
                <Slider label="Intensity" value={alienSettings.interference.visualNoiseIntensity} min={1} max={10} onChange={v => setAlienSettings({ interference: { ...alienSettings.interference, visualNoiseIntensity: v } })} />
              )}
              <Toggle label="Opacity Flickering" value={alienSettings.interference.opacityEnabled} onChange={v => setAlienSettings({ interference: { ...alienSettings.interference, opacityEnabled: v } })} />
              {alienSettings.interference.opacityEnabled && (
                <Slider label="Intensity" value={alienSettings.interference.opacityIntensity} min={1} max={10} onChange={v => setAlienSettings({ interference: { ...alienSettings.interference, opacityIntensity: v } })} />
              )}
            </Card>
          </>
        )}

        {tab === 'taskSwitch' && (
          <>
            <Card>
              <h3 className="font-bold text-sm mb-4">Dynamic N</h3>
              <Toggle label="Dynamic N (all channels)" value={alienSettings.taskSwitching.dynamicN} onChange={v => setAlienSettings({ taskSwitching: { ...alienSettings.taskSwitching, dynamicN: v } })} />
              {alienSettings.taskSwitching.dynamicN && (
                <div className="mt-3 space-y-4">
                  <Slider label="Min N" value={alienSettings.taskSwitching.dynamicNMin} min={1} max={99} onChange={v => setAlienSettings({ taskSwitching: { ...alienSettings.taskSwitching, dynamicNMin: v } })} />
                  <Slider label="Max N" value={alienSettings.taskSwitching.dynamicNMax} min={2} max={100} onChange={v => setAlienSettings({ taskSwitching: { ...alienSettings.taskSwitching, dynamicNMax: v } })} />
                  <Slider label="Intensity" value={alienSettings.taskSwitching.dynamicNIntensity} min={1} max={10} onChange={v => setAlienSettings({ taskSwitching: { ...alienSettings.taskSwitching, dynamicNIntensity: v } })} />
                </div>
              )}
            </Card>

            <Card>
              <h3 className="font-bold text-sm mb-4">Dynamic Speed</h3>
              <Toggle label="Dynamic Speed" value={alienSettings.taskSwitching.dynamicSpeed} onChange={v => setAlienSettings({ taskSwitching: { ...alienSettings.taskSwitching, dynamicSpeed: v } })} />
              {alienSettings.taskSwitching.dynamicSpeed && (
                <div className="mt-3 space-y-4">
                  <Slider label="Min" value={alienSettings.taskSwitching.dynamicSpeedMin} min={100} max={19000} step={100} onChange={v => setAlienSettings({ taskSwitching: { ...alienSettings.taskSwitching, dynamicSpeedMin: v } })} unit="ms" />
                  <Slider label="Max" value={alienSettings.taskSwitching.dynamicSpeedMax} min={200} max={20000} step={100} onChange={v => setAlienSettings({ taskSwitching: { ...alienSettings.taskSwitching, dynamicSpeedMax: v } })} unit="ms" />
                  <Slider label="Intensity" value={alienSettings.taskSwitching.dynamicSpeedIntensity} min={1} max={10} onChange={v => setAlienSettings({ taskSwitching: { ...alienSettings.taskSwitching, dynamicSpeedIntensity: v } })} />
                </div>
              )}
            </Card>

            <Card>
              <h3 className="font-bold text-sm mb-4">Channel Switching</h3>
              <Toggle label="Enable" value={alienSettings.taskSwitching.channelSwitching} onChange={v => setAlienSettings({ taskSwitching: { ...alienSettings.taskSwitching, channelSwitching: v } })} />
              {alienSettings.taskSwitching.channelSwitching && (
                <Slider label="Intensity" value={alienSettings.taskSwitching.channelSwitchingIntensity} min={1} max={10} onChange={v => setAlienSettings({ taskSwitching: { ...alienSettings.taskSwitching, channelSwitchingIntensity: v } })} />
              )}
            </Card>
          </>
        )}
      </div>

      <div className="px-5 pb-6 pt-2">
        <Button onClick={() => setScreen('alien-game')} variant="primary" size="lg" className="w-full bg-gradient-to-r from-neon-pink to-red-600" icon={<Play className="w-5 h-5" />}>
          Start Training
        </Button>
      </div>
    </div>
  );
}
