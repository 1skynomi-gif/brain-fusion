import { useState } from 'react';
import { useStore } from '../../store/useStore';
import { Card } from '../ui/Card';
import { Slider } from '../ui/Slider';
import { Toggle } from '../ui/Toggle';
import { Button } from '../ui/Button';
import { ArrowLeft, Play, Zap } from 'lucide-react';

type Tab = 'core' | 'interference' | 'taskSwitch';

export function AdvancedSettingsScreen() {
  const { settings, advancedCore, advancedInterference, advancedTaskSwitching, setAdvancedCore, setAdvancedInterference, setAdvancedTaskSwitching, setScreen } = useStore();
  const dark = settings.theme === 'dark';
  const [tab, setTab] = useState<Tab>('core');

  const tabs: { id: Tab; label: string; icon: string }[] = [
    { id: 'core', label: 'Core', icon: '⚙️' },
    { id: 'interference', label: 'Interference', icon: '🌀' },
    { id: 'taskSwitch', label: 'Task Switch', icon: '🔀' },
  ];

  const activeChannels = Object.entries(advancedCore.channels).filter(([k, v]) => {
    if (k === 'audio1Type' || k === 'audio2Type') return false;
    return v === true;
  }).map(([k]) => k);

  return (
    <div className={`h-full flex flex-col ${dark ? 'bg-dark-bg text-dark-text' : 'bg-gray-50 text-gray-900'}`}>
      <div className="px-5 pt-6 pb-2 flex items-center gap-3">
        <button onClick={() => setScreen('home')} className={`w-10 h-10 rounded-xl flex items-center justify-center ${dark ? 'bg-dark-surface' : 'bg-white shadow-sm'}`}>
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex-1">
          <h1 className="text-xl font-bold">Advanced N-Back</h1>
          <p className={`text-xs ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Multi-channel cognitive challenge</p>
        </div>
        <Zap className={`w-6 h-6 ${dark ? 'text-neon-purple' : 'text-brand-500'}`} />
      </div>

      {/* Tabs */}
      <div className="px-5 py-2 flex gap-2">
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
              tab === t.id
                ? 'bg-gradient-to-r from-neon-purple to-brand-500 text-white'
                : dark ? 'bg-dark-surface text-dark-muted' : 'bg-gray-100 text-gray-500'
            }`}
          >
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-6 space-y-4">
        {tab === 'core' && (
          <>
            <Card>
              <h3 className="font-bold text-sm mb-4">Base Parameters</h3>
              <div className="space-y-5">
                <Slider label="N-Back Level" value={advancedCore.n} min={1} max={100} onChange={v => setAdvancedCore({ n: v })} />
                <Slider label="Speed" value={advancedCore.speed} min={100} max={10000} step={100} onChange={v => setAdvancedCore({ speed: v })} unit="ms" />
                <Slider label="Stimuli Per Session" value={advancedCore.stimuliCount} min={25} max={10000} step={5} onChange={v => setAdvancedCore({ stimuliCount: v })} />
                <Slider label="Match Percentage" value={advancedCore.matchPercent} min={10} max={40} step={5} onChange={v => setAdvancedCore({ matchPercent: v })} unit="%" />
                <Slider label="Grid Size" value={advancedCore.gridSize} min={3} max={8} onChange={v => setAdvancedCore({ gridSize: v })} formatValue={v => `${v}×${v}`} />
              </div>
            </Card>

            <Card>
              <h3 className="font-bold text-sm mb-4">Channels</h3>
              <div className="space-y-2">
                <Toggle label="📍 Position" value={advancedCore.channels.position} onChange={v => setAdvancedCore({ channels: { ...advancedCore.channels, position: v } })} />
                <Toggle label="🔷 Shape (9 shapes)" value={advancedCore.channels.shape} onChange={v => setAdvancedCore({ channels: { ...advancedCore.channels, shape: v } })} />
                <Toggle label="🎨 Color (6 colors)" value={advancedCore.channels.color} onChange={v => setAdvancedCore({ channels: { ...advancedCore.channels, color: v } })} />

                <div className={`p-3 rounded-xl ${dark ? 'bg-dark-surface' : 'bg-gray-50'}`}>
                  <Toggle label="🔊 Audio Channel 1" value={advancedCore.channels.audio1} onChange={v => setAdvancedCore({ channels: { ...advancedCore.channels, audio1: v } })} />
                  {advancedCore.channels.audio1 && (
                    <div className="ml-4 mt-2 space-y-1">
                      {(['piano', 'letters', 'numbers'] as const).map(type => (
                        <label key={type} className="flex items-center gap-2 text-xs">
                          <input
                            type="checkbox"
                            checked={advancedCore.channels.audio1Type.includes(type)}
                            onChange={e => {
                              const types = e.target.checked
                                ? [...advancedCore.channels.audio1Type, type]
                                : advancedCore.channels.audio1Type.filter(t => t !== type);
                              setAdvancedCore({ channels: { ...advancedCore.channels, audio1Type: types.length ? types : ['letters'] } });
                            }}
                            className="rounded"
                          />
                          {type === 'piano' ? '🎹 Piano (9 notes)' : type === 'letters' ? '🔤 Letters (15)' : '🔢 Numbers (1-20)'}
                        </label>
                      ))}
                    </div>
                  )}
                </div>

                <div className={`p-3 rounded-xl ${dark ? 'bg-dark-surface' : 'bg-gray-50'}`}>
                  <Toggle label="🎧 Audio Channel 2 (L/R split)" value={advancedCore.channels.audio2} onChange={v => setAdvancedCore({ channels: { ...advancedCore.channels, audio2: v } })} />
                  {advancedCore.channels.audio2 && (
                    <div className="ml-4 mt-2 space-y-1">
                      <p className={`text-[10px] mb-1 ${dark ? 'text-neon-cyan' : 'text-brand-500'}`}>Ch1→Right ear, Ch2→Left ear</p>
                      {(['piano', 'letters', 'numbers'] as const).map(type => (
                        <label key={type} className="flex items-center gap-2 text-xs">
                          <input
                            type="checkbox"
                            checked={advancedCore.channels.audio2Type.includes(type)}
                            onChange={e => {
                              const types = e.target.checked
                                ? [...advancedCore.channels.audio2Type, type]
                                : advancedCore.channels.audio2Type.filter(t => t !== type);
                              setAdvancedCore({ channels: { ...advancedCore.channels, audio2Type: types.length ? types : ['piano'] } });
                            }}
                            className="rounded"
                          />
                          {type === 'piano' ? '🎹 Piano (9 notes)' : type === 'letters' ? '🔤 Letters (15)' : '🔢 Numbers (1-20)'}
                        </label>
                      ))}
                    </div>
                  )}
                </div>

                <Toggle label="📳 Vibration" value={advancedCore.channels.vibration} onChange={v => setAdvancedCore({ channels: { ...advancedCore.channels, vibration: v } })} description="Cell vibrates or not" />
                <Toggle label="📐 Size" value={advancedCore.channels.size} onChange={v => setAdvancedCore({ channels: { ...advancedCore.channels, size: v } })} description="Requires Shape. Small or Large" />
                <Toggle label="🧵 Texture" value={advancedCore.channels.texture} onChange={v => setAdvancedCore({ channels: { ...advancedCore.channels, texture: v } })} description="None / Horizontal / Vertical lines" />
                <Toggle label="🔢 Visual Numbers (1-9)" value={advancedCore.channels.visualNumbers} onChange={v => setAdvancedCore({ channels: { ...advancedCore.channels, visualNumbers: v } })} />
                <Toggle label="🔤 Visual Letters (A-Z)" value={advancedCore.channels.visualLetters} onChange={v => setAdvancedCore({ channels: { ...advancedCore.channels, visualLetters: v } })} />
              </div>
            </Card>

            <Card>
              <h3 className="font-bold text-sm mb-4">Adaptive Difficulty</h3>
              <Toggle label="Enable Adaptive" value={advancedCore.adaptiveEnabled} onChange={v => setAdvancedCore({ adaptiveEnabled: v })} />
              {advancedCore.adaptiveEnabled && (
                <div className="mt-3 space-y-4">
                  <Slider label="Success Threshold" value={advancedCore.adaptiveThreshold} min={50} max={95} step={5} onChange={v => setAdvancedCore({ adaptiveThreshold: v })} unit="%" />
                  <div>
                    <p className={`text-xs font-medium mb-2 ${dark ? 'text-dark-text' : 'text-gray-700'}`}>Priority</p>
                    <div className="flex gap-2">
                      {(['speed', 'channels', 'n'] as const).map(p => (
                        <button
                          key={p}
                          onClick={() => setAdvancedCore({ adaptivePriority: p })}
                          className={`flex-1 py-2 rounded-xl text-xs font-bold ${
                            advancedCore.adaptivePriority === p
                              ? 'bg-gradient-to-r from-neon-purple to-brand-500 text-white'
                              : dark ? 'bg-dark-surface text-dark-muted' : 'bg-gray-100 text-gray-500'
                          }`}
                        >
                          {p === 'speed' ? '⚡ Speed' : p === 'channels' ? '📡 Channels' : '🔢 N Level'}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </Card>
          </>
        )}

        {tab === 'interference' && (
          <>
            <Card>
              <h3 className="font-bold text-sm mb-4">Lure Trials</h3>
              <Slider label="Lure Percentage" value={advancedInterference.lureTrials} min={10} max={100} step={10} onChange={v => setAdvancedInterference({ lureTrials: v })} unit="%" />
              <p className={`text-[10px] mt-2 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>
                N±1 position matches that create false familiarity
              </p>
            </Card>

            <Card>
              <h3 className="font-bold text-sm mb-4">Stimulus Fading</h3>
              <Toggle label="Enable Fading" value={advancedInterference.fadingEnabled} onChange={v => setAdvancedInterference({ fadingEnabled: v })} description="Stimuli gradually fade out" />
              {advancedInterference.fadingEnabled && (
                <Slider label="Fading Intensity" value={advancedInterference.fadingIntensity} min={1} max={10} onChange={v => setAdvancedInterference({ fadingIntensity: v })} />
              )}
            </Card>

            <Card>
              <h3 className="font-bold text-sm mb-4">Audio Noise</h3>
              <div className="flex gap-2 mb-3">
                {(['none', 'pink', 'brown'] as const).map(type => (
                  <button
                    key={type}
                    onClick={() => setAdvancedInterference({ noiseType: type })}
                    className={`flex-1 py-2 rounded-xl text-xs font-bold ${
                      advancedInterference.noiseType === type
                        ? 'bg-gradient-to-r from-neon-purple to-brand-500 text-white'
                        : dark ? 'bg-dark-surface text-dark-muted' : 'bg-gray-100 text-gray-500'
                    }`}
                  >
                    {type === 'none' ? 'Off' : type === 'pink' ? '🩷 Pink' : '🤎 Brown'}
                  </button>
                ))}
              </div>
              {advancedInterference.noiseType !== 'none' && (
                <Slider label="Noise Intensity" value={advancedInterference.noiseIntensity} min={1} max={10} onChange={v => setAdvancedInterference({ noiseIntensity: v })} />
              )}
            </Card>

            <Card>
              <h3 className="font-bold text-sm mb-4">Screen Opacity</h3>
              <Toggle label="Random Dimming" value={advancedInterference.opacityEnabled} onChange={v => setAdvancedInterference({ opacityEnabled: v })} description="Screen brightness randomly drops" />
              {advancedInterference.opacityEnabled && (
                <Slider label="Intensity" value={advancedInterference.opacityIntensity} min={1} max={10} onChange={v => setAdvancedInterference({ opacityIntensity: v })} />
              )}
            </Card>

            <Card>
              <h3 className="font-bold text-sm mb-4">Go/No-Go</h3>
              <Toggle label="Enable Go/No-Go" value={advancedInterference.goNoGoEnabled} onChange={v => setAdvancedInterference({ goNoGoEnabled: v })} description="Screen locks randomly - don't respond!" />
              {advancedInterference.goNoGoEnabled && (
                <Slider label="Intensity" value={advancedInterference.goNoGoIntensity} min={1} max={10} onChange={v => setAdvancedInterference({ goNoGoIntensity: v })} />
              )}
            </Card>

            <Card>
              <h3 className="font-bold text-sm mb-4">Visual Noise</h3>
              <Toggle label="Pixel Noise" value={advancedInterference.visualNoiseEnabled} onChange={v => setAdvancedInterference({ visualNoiseEnabled: v })} description="Random pixel noise on stimulus area" />
              {advancedInterference.visualNoiseEnabled && (
                <Slider label="Intensity" value={advancedInterference.visualNoiseIntensity} min={1} max={10} onChange={v => setAdvancedInterference({ visualNoiseIntensity: v })} />
              )}
            </Card>
          </>
        )}

        {tab === 'taskSwitch' && (
          <>
            <Card>
              <h3 className="font-bold text-sm mb-4">Dynamic N</h3>
              <Toggle label="Enable Dynamic N" value={advancedTaskSwitching.dynamicN} onChange={v => setAdvancedTaskSwitching({ dynamicN: v })} description="N changes during session" />
              {advancedTaskSwitching.dynamicN && (
                <div className="mt-3 space-y-4">
                  <Slider label="Minimum N" value={advancedTaskSwitching.dynamicNMin} min={1} max={99} onChange={v => setAdvancedTaskSwitching({ dynamicNMin: v })} />
                  <Slider label="Maximum N" value={advancedTaskSwitching.dynamicNMax} min={2} max={100} onChange={v => setAdvancedTaskSwitching({ dynamicNMax: v })} />
                  <Slider label="Change Intensity" value={advancedTaskSwitching.dynamicNIntensity} min={1} max={10} onChange={v => setAdvancedTaskSwitching({ dynamicNIntensity: v })} />
                </div>
              )}
            </Card>

            <Card>
              <h3 className="font-bold text-sm mb-4">Multi-Channel Dynamic N</h3>
              <Toggle label="Per-Channel N" value={advancedTaskSwitching.multiChannelN} onChange={v => setAdvancedTaskSwitching({ multiChannelN: v })} description="Different N for each channel" />
              {advancedTaskSwitching.multiChannelN && (
                <div className="mt-3 space-y-3">
                  {activeChannels.map(ch => (
                    <div key={ch} className={`p-3 rounded-xl ${dark ? 'bg-dark-surface' : 'bg-gray-50'}`}>
                      <Slider
                        label={`${ch} N`}
                        value={advancedTaskSwitching.channelNValues[ch] ?? advancedCore.n}
                        min={1}
                        max={100}
                        onChange={v => setAdvancedTaskSwitching({
                          channelNValues: { ...advancedTaskSwitching.channelNValues, [ch]: v }
                        })}
                      />
                      <Toggle
                        label="Dynamic"
                        value={advancedTaskSwitching.channelNDynamic[ch] ?? false}
                        onChange={v => setAdvancedTaskSwitching({
                          channelNDynamic: { ...advancedTaskSwitching.channelNDynamic, [ch]: v }
                        })}
                      />
                      {advancedTaskSwitching.channelNDynamic[ch] && (
                        <div className="space-y-2 mt-2">
                          <Slider label="Min" value={advancedTaskSwitching.channelNDynamicMin[ch] ?? 1} min={1} max={99} onChange={v => setAdvancedTaskSwitching({ channelNDynamicMin: { ...advancedTaskSwitching.channelNDynamicMin, [ch]: v } })} />
                          <Slider label="Max" value={advancedTaskSwitching.channelNDynamicMax[ch] ?? 10} min={2} max={100} onChange={v => setAdvancedTaskSwitching({ channelNDynamicMax: { ...advancedTaskSwitching.channelNDynamicMax, [ch]: v } })} />
                          <Slider label="Intensity" value={advancedTaskSwitching.channelNDynamicIntensity[ch] ?? 5} min={1} max={10} onChange={v => setAdvancedTaskSwitching({ channelNDynamicIntensity: { ...advancedTaskSwitching.channelNDynamicIntensity, [ch]: v } })} />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </Card>

            <Card>
              <h3 className="font-bold text-sm mb-4">Dynamic Speed</h3>
              <Toggle label="Enable Dynamic Speed" value={advancedTaskSwitching.dynamicSpeed} onChange={v => setAdvancedTaskSwitching({ dynamicSpeed: v })} description="Speed changes during session" />
              {advancedTaskSwitching.dynamicSpeed && (
                <div className="mt-3 space-y-4">
                  <Slider label="Min Speed" value={advancedTaskSwitching.dynamicSpeedMin} min={100} max={9900} step={100} onChange={v => setAdvancedTaskSwitching({ dynamicSpeedMin: v })} unit="ms" />
                  <Slider label="Max Speed" value={advancedTaskSwitching.dynamicSpeedMax} min={200} max={10000} step={100} onChange={v => setAdvancedTaskSwitching({ dynamicSpeedMax: v })} unit="ms" />
                  <Slider label="Change Intensity" value={advancedTaskSwitching.dynamicSpeedIntensity} min={1} max={10} onChange={v => setAdvancedTaskSwitching({ dynamicSpeedIntensity: v })} />
                </div>
              )}
            </Card>

            <Card>
              <h3 className="font-bold text-sm mb-4">Channel Switching</h3>
              <Toggle label="Enable Channel Switching" value={advancedTaskSwitching.channelSwitching} onChange={v => setAdvancedTaskSwitching({ channelSwitching: v })} description="Randomly hides/shows channel response buttons" />
              {advancedTaskSwitching.channelSwitching && (
                <Slider label="Intensity" value={advancedTaskSwitching.channelSwitchingIntensity} min={1} max={10} onChange={v => setAdvancedTaskSwitching({ channelSwitchingIntensity: v })} />
              )}
            </Card>
          </>
        )}
      </div>

      <div className="px-5 pb-6 pt-2">
        <Button onClick={() => setScreen('advanced-game')} variant="primary" size="lg" className="w-full" icon={<Play className="w-5 h-5" />}>
          Start Training
        </Button>
      </div>
    </div>
  );
}
