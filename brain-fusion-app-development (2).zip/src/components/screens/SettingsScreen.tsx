import { useStore } from '../../store/useStore';
import { Card } from '../ui/Card';
import { Toggle } from '../ui/Toggle';
import { ArrowLeft, Sun, Moon, Sparkles, Vibrate, Volume2 } from 'lucide-react';

export function SettingsScreen() {
  const { settings, setSettings, setScreen } = useStore();
  const dark = settings.theme === 'dark';

  return (
    <div className={`h-full flex flex-col ${dark ? 'bg-dark-bg text-dark-text' : 'bg-gray-50 text-gray-900'}`}>
      <div className="px-5 pt-6 pb-4 flex items-center gap-3">
        <button onClick={() => setScreen('home')} className={`w-10 h-10 rounded-xl flex items-center justify-center ${dark ? 'bg-dark-surface' : 'bg-white shadow-sm'}`}>
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-xl font-bold">Settings</h1>
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-6 space-y-4">
        {/* Theme */}
        <Card>
          <h3 className="font-bold text-sm mb-3 flex items-center gap-2">
            {dark ? <Moon className="w-4 h-4 text-brand-400" /> : <Sun className="w-4 h-4 text-yellow-500" />}
            Theme
          </h3>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setSettings({ theme: 'dark' })}
              className={`py-3 rounded-xl font-bold text-sm transition-all ${
                dark
                  ? 'bg-gradient-to-r from-brand-500 to-brand-600 text-white'
                  : 'bg-gray-100 text-gray-500'
              }`}
            >
              🌙 Dark
            </button>
            <button
              onClick={() => setSettings({ theme: 'light' })}
              className={`py-3 rounded-xl font-bold text-sm transition-all ${
                !dark
                  ? 'bg-gradient-to-r from-brand-500 to-brand-600 text-white'
                  : 'bg-dark-surface text-dark-muted'
              }`}
            >
              ☀️ Light
            </button>
          </div>
        </Card>

        {/* Animations */}
        <Card>
          <h3 className="font-bold text-sm mb-3 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-yellow-400" /> Animations
          </h3>
          <div className="space-y-1">
            <Toggle
              label="All Animations"
              value={settings.animationsEnabled}
              onChange={v => setSettings({ animationsEnabled: v })}
              description="Master toggle for all animations"
            />
            <Toggle
              label="Particle Effects"
              value={settings.particleEffects}
              onChange={v => setSettings({ particleEffects: v })}
              description="Background particles and sparkles"
            />
            <Toggle
              label="Transition Effects"
              value={settings.transitionEffects}
              onChange={v => setSettings({ transitionEffects: v })}
              description="Screen and element transitions"
            />
          </div>
        </Card>

        {/* Feedback */}
        <Card>
          <h3 className="font-bold text-sm mb-3 flex items-center gap-2">
            <Vibrate className="w-4 h-4 text-neon-green" /> Feedback
          </h3>
          <div className="space-y-1">
            <Toggle
              label="Haptic Feedback"
              value={settings.hapticFeedback}
              onChange={v => setSettings({ hapticFeedback: v })}
              description="Vibration on interactions"
            />
            <Toggle
              label="Sound Effects"
              value={settings.soundEnabled}
              onChange={v => setSettings({ soundEnabled: v })}
              description="UI sound effects"
            />
          </div>
        </Card>

        {/* About */}
        <Card>
          <h3 className="font-bold text-sm mb-3 flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-brand-400" /> About
          </h3>
          <p className={`text-xs ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>
            Brain Fusion v1.0.0<br />
            Professional cognitive training with N-Back exercises.<br />
            Train your working memory, processing speed, and cognitive flexibility.
          </p>
        </Card>
      </div>
    </div>
  );
}
