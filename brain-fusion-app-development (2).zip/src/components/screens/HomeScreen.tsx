import { useStore } from '../../store/useStore';
import { Card } from '../ui/Card';
import { Brain, Settings, User, Zap, Dumbbell, Calculator, Skull } from 'lucide-react';

export function HomeScreen() {
  const { settings, profile, setScreen } = useStore();
  const dark = settings.theme === 'dark';
  const anims = settings.animationsEnabled;

  const modes = [
    {
      id: 'classic',
      title: 'Classic N-Back',
      desc: 'Position & Audio dual task',
      icon: <Brain className="w-8 h-8" />,
      gradient: 'from-brand-500 to-brand-700',
      glow: 'shadow-brand-500/30',
    },
    {
      id: 'advanced',
      title: 'Advanced N-Back',
      desc: 'Multi-channel cognitive challenge',
      icon: <Zap className="w-8 h-8" />,
      gradient: 'from-neon-purple to-brand-600',
      glow: 'shadow-neon-purple/30',
    },
    {
      id: 'arithmetic',
      title: 'Arithmetic N-Back',
      desc: 'Math meets working memory',
      icon: <Calculator className="w-8 h-8" />,
      gradient: 'from-neon-green to-emerald-600',
      glow: 'shadow-neon-green/30',
    },
    {
      id: 'alien',
      title: 'Alien Mode',
      desc: 'Multi-speed independent channels',
      icon: <Skull className="w-8 h-8" />,
      gradient: 'from-neon-pink to-red-600',
      glow: 'shadow-neon-pink/30',
    },
  ];

  return (
    <div className={`h-full flex flex-col ${dark ? 'bg-dark-bg text-dark-text' : 'bg-gray-50 text-gray-900'}`}>
      {/* Header */}
      <div className="px-5 pt-6 pb-2 flex items-center justify-between">
        <div>
          <h1 className={`text-2xl font-black tracking-tight ${anims ? 'animate-float' : ''}`}>
            <span className="bg-gradient-to-r from-brand-400 via-neon-cyan to-brand-500 bg-clip-text text-transparent">
              Brain Fusion
            </span>
          </h1>
          <p className={`text-xs mt-0.5 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Train your cognitive power</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setScreen('profile')}
            className={`w-10 h-10 rounded-xl flex items-center justify-center ${anims ? 'transition-all duration-200' : ''} ${
              dark ? 'bg-dark-surface hover:bg-dark-border' : 'bg-white hover:bg-gray-100 shadow-sm'
            }`}
          >
            <User className="w-5 h-5" />
          </button>
          <button
            onClick={() => setScreen('settings')}
            className={`w-10 h-10 rounded-xl flex items-center justify-center ${anims ? 'transition-all duration-200' : ''} ${
              dark ? 'bg-dark-surface hover:bg-dark-border' : 'bg-white hover:bg-gray-100 shadow-sm'
            }`}
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Profile mini card */}
      <div className="px-5 py-3">
        <Card glow className="flex items-center gap-4">
          <div className={`w-14 h-14 rounded-2xl flex items-center justify-center bg-gradient-to-br from-brand-500 to-neon-cyan ${anims ? 'animate-pulse-glow' : ''}`}>
            <Dumbbell className="w-7 h-7 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-bold text-base truncate">{profile.name}</p>
            <p className={`text-xs ${dark ? 'text-neon-cyan' : 'text-brand-500'}`}>{profile.title}</p>
            <div className="mt-1.5 flex items-center gap-2">
              <div className={`flex-1 h-2 rounded-full overflow-hidden ${dark ? 'bg-dark-border' : 'bg-gray-200'}`}>
                <div
                  className="h-full rounded-full bg-gradient-to-r from-brand-500 to-neon-cyan transition-all duration-500"
                  style={{ width: `${(profile.xp / profile.xpToNext) * 100}%` }}
                />
              </div>
              <span className={`text-[10px] font-bold ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>
                Lv.{profile.level}
              </span>
            </div>
          </div>
        </Card>
      </div>

      {/* Game modes */}
      <div className="flex-1 overflow-y-auto px-5 pb-6">
        <h2 className={`text-sm font-bold uppercase tracking-widest mb-3 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>
          Training Modes
        </h2>
        <div className="space-y-3">
          {modes.map((mode, i) => (
            <Card
              key={mode.id}
              onClick={() => setScreen(`${mode.id}-settings`)}
              className={`${anims ? 'hover:scale-[1.02]' : ''}`}
            >
              <div className="flex items-center gap-4">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center bg-gradient-to-br ${mode.gradient} text-white shadow-lg ${mode.glow}`}
                  style={anims ? { animationDelay: `${i * 0.1}s` } : undefined}
                >
                  {mode.icon}
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-base">{mode.title}</h3>
                  <p className={`text-xs mt-0.5 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>{mode.desc}</p>
                </div>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${dark ? 'bg-dark-surface' : 'bg-gray-100'}`}>
                  <span className="text-lg">›</span>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Quick Stats */}
        <h2 className={`text-sm font-bold uppercase tracking-widest mt-6 mb-3 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>
          Quick Stats
        </h2>
        <div className="grid grid-cols-2 gap-3">
          <Card>
            <p className={`text-[10px] uppercase tracking-wider ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Sessions</p>
            <p className="text-2xl font-black mt-1">{profile.totalSessions}</p>
          </Card>
          <Card>
            <p className={`text-[10px] uppercase tracking-wider ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Best Accuracy</p>
            <p className="text-2xl font-black mt-1">{profile.bestAccuracy.toFixed(1)}%</p>
          </Card>
          <Card>
            <p className={`text-[10px] uppercase tracking-wider ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Total Hits</p>
            <p className="text-2xl font-black mt-1">{profile.totalCorrect}</p>
          </Card>
          <Card>
            <p className={`text-[10px] uppercase tracking-wider ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Streak</p>
            <p className="text-2xl font-black mt-1">{profile.streak}🔥</p>
          </Card>
        </div>
      </div>
    </div>
  );
}
