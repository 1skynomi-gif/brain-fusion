import { useState, useEffect, useCallback, useRef } from 'react';
import { useStore } from '../../store/useStore';
import { generateSequence, getLetterForIndex } from '../../utils/stimulusGenerator';
import { speakLetter, playCorrectSound, playWrongSound } from '../../utils/audio';
import { X, Pause, Play } from 'lucide-react';
import type { GeneratedStimulus } from '../../utils/stimulusGenerator';

interface ChannelResult {
  hits: number;
  misses: number;
  falseAlarms: number;
  correctRejections: number;
  accuracy: number;
}

export function ClassicGame() {
  const { settings, classicSettings, setScreen, addSession, addXP, setClassicSettings } = useStore();
  const dark = settings.theme === 'dark';
  const anims = settings.animationsEnabled;

  const [phase, setPhase] = useState<'ready' | 'playing' | 'paused' | 'result'>('ready');
  const [currentIndex, setCurrentIndex] = useState(-1);
  const [sequence, setSequence] = useState<GeneratedStimulus[]>([]);
  const [positionResponses, setPositionResponses] = useState<Set<number>>(new Set());
  const [audioResponses, setAudioResponses] = useState<Set<number>>(new Set());
  const [feedback, setFeedback] = useState<{ type: 'correct' | 'wrong' | null; channel: string }>({ type: null, channel: '' });
  const [positionResult, setPositionResult] = useState<ChannelResult>({ hits: 0, misses: 0, falseAlarms: 0, correctRejections: 0, accuracy: 0 });
  const [audioResult, setAudioResult] = useState<ChannelResult>({ hits: 0, misses: 0, falseAlarms: 0, correctRejections: 0, accuracy: 0 });
  const [totalAccuracy, setTotalAccuracy] = useState(0);
  const [showStimulus, setShowStimulus] = useState(false);
  const [startTime, setStartTime] = useState(0);

  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pauseRef = useRef(false);

  const generateGame = useCallback(() => {
    const seq = generateSequence({
      n: classicSettings.n,
      totalStimuli: classicSettings.stimuliCount,
      matchPercent: 25,
      channels: ['position', 'audio1'],
      gridSize: 3,
    });
    setSequence(seq);
    setPositionResponses(new Set());
    setAudioResponses(new Set());
    setCurrentIndex(-1);
    setFeedback({ type: null, channel: '' });
  }, [classicSettings.n, classicSettings.stimuliCount]);

  useEffect(() => {
    generateGame();
  }, [generateGame]);

  const startGame = useCallback(() => {
    setPhase('playing');
    setStartTime(Date.now());
    setCurrentIndex(0);
    setShowStimulus(true);
  }, []);

  // Advance stimuli
  useEffect(() => {
    if (phase !== 'playing' || currentIndex < 0) return;

    // Play audio for current stimulus
    if (sequence[currentIndex]) {
      const audioIdx = sequence[currentIndex].stimulus.audio1;
      if (audioIdx !== undefined) {
        const letter = getLetterForIndex(audioIdx);
        const rate = Math.max(0.7, Math.min(2.5, 2500 / classicSettings.speed));
        speakLetter(letter, rate);
      }
    }

    setShowStimulus(true);
    const showTimer = setTimeout(() => {
      setShowStimulus(false);
    }, Math.min(classicSettings.speed * 0.8, classicSettings.speed - 100));

    timerRef.current = setTimeout(() => {
      if (pauseRef.current) return;
      setCurrentIndex(prev => {
        if (prev >= sequence.length - 1) {
          setPhase('result');
          return prev;
        }
        return prev + 1;
      });
    }, classicSettings.speed);

    return () => {
      clearTimeout(showTimer);
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [phase, currentIndex, sequence, classicSettings.speed]);

  // Calculate results when game ends
  useEffect(() => {
    if (phase !== 'result') return;

    const calcResult = (responses: Set<number>, channelName: string): ChannelResult => {
      let hits = 0, misses = 0, falseAlarms = 0, correctRejections = 0;

      for (let i = 0; i < sequence.length; i++) {
        const isMatch = sequence[i].matches.find(m => m.channel === channelName)?.isMatch ?? false;
        const responded = responses.has(i);

        if (isMatch && responded) hits++;
        else if (isMatch && !responded) misses++;
        else if (!isMatch && responded) falseAlarms++;
        else correctRejections++;
      }

      // Accuracy formula: hits contribute heavily, misses reduce significantly, false alarms reduce moderately
      const totalMatches = hits + misses;
      const hitRate = totalMatches > 0 ? hits / totalMatches : 0;
      const faPenalty = falseAlarms > 0 ? (falseAlarms / (falseAlarms + correctRejections)) * 0.5 : 0;
      const accuracy = Math.max(0, Math.min(100, (hitRate * 100) - (faPenalty * 30)));

      return { hits, misses, falseAlarms, correctRejections, accuracy };
    };

    const posRes = calcResult(positionResponses, 'position');
    const audRes = calcResult(audioResponses, 'audio1');
    setPositionResult(posRes);
    setAudioResult(audRes);

    const avg = (posRes.accuracy + audRes.accuracy) / 2;
    setTotalAccuracy(avg);

    const duration = Math.round((Date.now() - startTime) / 1000);
    const xp = Math.round(avg * 0.5 + classicSettings.n * 5 + classicSettings.stimuliCount * 0.1);

    addSession({
      mode: 'classic',
      date: new Date().toISOString(),
      accuracy: avg,
      n: classicSettings.n,
      channels: ['position', 'audio'],
      hits: posRes.hits + audRes.hits,
      misses: posRes.misses + audRes.misses,
      falseAlarms: posRes.falseAlarms + audRes.falseAlarms,
      correctRejections: posRes.correctRejections + audRes.correctRejections,
      xpEarned: xp,
      duration,
      channelDetails: {
        position: posRes,
        audio: audRes,
      },
    });
    addXP(xp);

    // Adaptive logic
    if (classicSettings.adaptiveEnabled) {
      if (avg >= classicSettings.adaptiveThreshold) {
        const newGood = classicSettings.consecutiveGood + 1;
        if (newGood >= 3) {
          setClassicSettings({ n: Math.min(classicSettings.n + 1, 10), consecutiveGood: 0, consecutiveBad: 0 });
        } else {
          setClassicSettings({ consecutiveGood: newGood, consecutiveBad: 0 });
        }
      } else {
        const newBad = classicSettings.consecutiveBad + 1;
        if (newBad >= 2) {
          setClassicSettings({ n: Math.max(classicSettings.n - 1, 1), consecutiveBad: 0, consecutiveGood: 0 });
        } else {
          setClassicSettings({ consecutiveBad: newBad, consecutiveGood: 0 });
        }
      }
    }
  }, [phase]);

  const handlePositionPress = () => {
    if (phase !== 'playing' || currentIndex < classicSettings.n) return;
    const newSet = new Set(positionResponses);
    newSet.add(currentIndex);
    setPositionResponses(newSet);

    const isMatch = sequence[currentIndex]?.matches.find(m => m.channel === 'position')?.isMatch ?? false;
    if (isMatch) {
      setFeedback({ type: 'correct', channel: 'position' });
      if (settings.soundEnabled) playCorrectSound();
    } else {
      setFeedback({ type: 'wrong', channel: 'position' });
      if (settings.soundEnabled) playWrongSound();
    }
    setTimeout(() => setFeedback({ type: null, channel: '' }), 300);
  };

  const handleAudioPress = () => {
    if (phase !== 'playing' || currentIndex < classicSettings.n) return;
    const newSet = new Set(audioResponses);
    newSet.add(currentIndex);
    setAudioResponses(newSet);

    const isMatch = sequence[currentIndex]?.matches.find(m => m.channel === 'audio1')?.isMatch ?? false;
    if (isMatch) {
      setFeedback({ type: 'correct', channel: 'audio' });
      if (settings.soundEnabled) playCorrectSound();
    } else {
      setFeedback({ type: 'wrong', channel: 'audio' });
      if (settings.soundEnabled) playWrongSound();
    }
    setTimeout(() => setFeedback({ type: null, channel: '' }), 300);
  };

  const togglePause = () => {
    if (phase === 'playing') {
      pauseRef.current = true;
      setPhase('paused');
      if (timerRef.current) clearTimeout(timerRef.current);
    } else if (phase === 'paused') {
      pauseRef.current = false;
      setPhase('playing');
      // Re-trigger by advancing index
      setCurrentIndex(prev => prev);
    }
  };

  // Ready screen
  if (phase === 'ready') {
    return (
      <div className={`h-full flex flex-col items-center justify-center ${dark ? 'bg-dark-bg text-dark-text' : 'bg-gray-50 text-gray-900'}`}>
        <div className={`w-24 h-24 rounded-3xl flex items-center justify-center bg-gradient-to-br from-brand-500 to-neon-cyan mb-6 ${anims ? 'animate-pulse-glow' : ''}`}>
          <span className="text-5xl">🧠</span>
        </div>
        <h2 className="text-2xl font-black mb-2">Classic {classicSettings.n}-Back</h2>
        <p className={`text-sm mb-1 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>
          {classicSettings.stimuliCount} stimuli • {classicSettings.speed}ms
        </p>
        <p className={`text-xs mb-8 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>
          Match position and audio with {classicSettings.n} steps back
        </p>
        <button
          onClick={startGame}
          className="w-20 h-20 rounded-full bg-gradient-to-r from-brand-500 to-neon-cyan flex items-center justify-center shadow-lg shadow-brand-500/40 active:scale-95 transition-transform"
        >
          <Play className="w-10 h-10 text-white ml-1" />
        </button>
        <button onClick={() => setScreen('classic-settings')} className={`mt-6 text-sm ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>
          ← Back to settings
        </button>
      </div>
    );
  }

  // Result screen
  if (phase === 'result') {
    return (
      <div className={`h-full flex flex-col ${dark ? 'bg-dark-bg text-dark-text' : 'bg-gray-50 text-gray-900'}`}>
        <div className="px-5 pt-6 pb-4 flex items-center justify-between">
          <h1 className="text-xl font-bold">Session Results</h1>
          <button onClick={() => setScreen('classic-settings')} className={`w-10 h-10 rounded-xl flex items-center justify-center ${dark ? 'bg-dark-surface' : 'bg-white shadow-sm'}`}>
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-5 pb-6 space-y-4">
          {/* Total Accuracy */}
          <div className={`rounded-3xl p-6 text-center ${dark ? 'bg-dark-card border border-dark-border' : 'bg-white shadow-sm'}`}>
            <p className={`text-xs uppercase tracking-wider mb-2 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Overall Accuracy</p>
            <p className={`text-6xl font-black ${
              totalAccuracy >= 80 ? 'text-green-400' : totalAccuracy >= 50 ? 'text-yellow-400' : 'text-red-400'
            }`}>
              {totalAccuracy.toFixed(1)}%
            </p>
            <p className={`text-sm mt-2 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>
              {classicSettings.n}-Back • {classicSettings.stimuliCount} stimuli
            </p>
          </div>

          {/* Channel Details */}
          {[
            { name: 'Position', result: positionResult, emoji: '📍' },
            { name: 'Audio', result: audioResult, emoji: '🔊' },
          ].map(ch => (
            <div key={ch.name} className={`rounded-3xl p-5 ${dark ? 'bg-dark-card border border-dark-border' : 'bg-white shadow-sm'}`}>
              <h3 className="font-bold text-sm mb-3">{ch.emoji} {ch.name} Channel</h3>
              <div className="grid grid-cols-2 gap-3 mb-3">
                <div className={`p-3 rounded-xl text-center ${dark ? 'bg-dark-surface' : 'bg-gray-50'}`}>
                  <p className="text-green-400 text-xl font-black">{ch.result.hits}</p>
                  <p className={`text-[10px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Hits ✓</p>
                </div>
                <div className={`p-3 rounded-xl text-center ${dark ? 'bg-dark-surface' : 'bg-gray-50'}`}>
                  <p className="text-red-400 text-xl font-black">{ch.result.misses}</p>
                  <p className={`text-[10px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Missed ✗</p>
                </div>
                <div className={`p-3 rounded-xl text-center ${dark ? 'bg-dark-surface' : 'bg-gray-50'}`}>
                  <p className="text-orange-400 text-xl font-black">{ch.result.falseAlarms}</p>
                  <p className={`text-[10px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>False Alarms</p>
                </div>
                <div className={`p-3 rounded-xl text-center ${dark ? 'bg-dark-surface' : 'bg-gray-50'}`}>
                  <p className="text-blue-400 text-xl font-black">{ch.result.correctRejections}</p>
                  <p className={`text-[10px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Correct Rej.</p>
                </div>
              </div>
              <div className={`h-2 rounded-full overflow-hidden ${dark ? 'bg-dark-border' : 'bg-gray-200'}`}>
                <div
                  className={`h-full rounded-full ${
                    ch.result.accuracy >= 80 ? 'bg-green-400' : ch.result.accuracy >= 50 ? 'bg-yellow-400' : 'bg-red-400'
                  }`}
                  style={{ width: `${ch.result.accuracy}%` }}
                />
              </div>
              <p className="text-right text-xs font-bold mt-1">{ch.result.accuracy.toFixed(1)}%</p>
            </div>
          ))}

          <div className="flex gap-3">
            <button
              onClick={() => { generateGame(); setPhase('ready'); }}
              className="flex-1 py-3 rounded-2xl font-bold text-sm bg-gradient-to-r from-brand-500 to-brand-600 text-white"
            >
              Play Again
            </button>
            <button
              onClick={() => setScreen('home')}
              className={`flex-1 py-3 rounded-2xl font-bold text-sm ${dark ? 'bg-dark-surface text-dark-text' : 'bg-gray-100 text-gray-700'}`}
            >
              Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Playing / Paused screen
  const currentStim = sequence[currentIndex];
  const position = currentStim?.stimulus.position ?? -1;

  return (
    <div className={`h-full flex flex-col ${dark ? 'bg-dark-bg text-dark-text' : 'bg-gray-50 text-gray-900'}`}>
      {/* Top bar */}
      <div className="px-5 pt-4 pb-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className={`text-xs font-bold px-2 py-1 rounded-lg ${dark ? 'bg-brand-500/20 text-brand-300' : 'bg-brand-50 text-brand-600'}`}>
            {classicSettings.n}-Back
          </span>
          <span className={`text-xs ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>
            {currentIndex + 1}/{sequence.length}
          </span>
        </div>
        <div className="flex gap-2">
          <button onClick={togglePause} className={`w-9 h-9 rounded-xl flex items-center justify-center ${dark ? 'bg-dark-surface' : 'bg-white shadow-sm'}`}>
            {phase === 'paused' ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
          </button>
          <button onClick={() => setScreen('classic-settings')} className={`w-9 h-9 rounded-xl flex items-center justify-center ${dark ? 'bg-dark-surface' : 'bg-white shadow-sm'}`}>
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Progress bar */}
      <div className="px-5 pb-2">
        <div className={`w-full h-1.5 rounded-full overflow-hidden ${dark ? 'bg-dark-border' : 'bg-gray-200'}`}>
          <div
            className="h-full rounded-full bg-gradient-to-r from-brand-500 to-neon-cyan transition-all duration-300"
            style={{ width: `${((currentIndex + 1) / sequence.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Paused overlay */}
      {phase === 'paused' && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/70">
          <div className="text-center">
            <p className="text-3xl font-black text-white mb-4">⏸ Paused</p>
            <button onClick={togglePause} className="px-8 py-3 rounded-2xl bg-gradient-to-r from-brand-500 to-brand-600 text-white font-bold">
              Resume
            </button>
          </div>
        </div>
      )}

      {/* Grid */}
      <div className="flex-1 flex items-center justify-center px-5">
        <div className="grid grid-cols-3 gap-2 w-full max-w-[280px] aspect-square">
          {Array.from({ length: 9 }, (_, i) => (
            <div
              key={i}
              className={`rounded-2xl flex items-center justify-center ${anims ? 'transition-all duration-200' : ''} ${
                showStimulus && position === i
                  ? 'bg-gradient-to-br from-brand-400 to-neon-cyan shadow-lg shadow-brand-500/40 scale-95'
                  : dark ? 'bg-dark-surface border border-dark-border' : 'bg-gray-100 border border-gray-200'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Response Buttons */}
      <div className="px-5 pb-8 pt-4">
        {/* Feedback indicator */}
        <div className="h-6 flex items-center justify-center mb-3">
          {feedback.type && (
            <span className={`text-xs font-bold px-3 py-1 rounded-full ${
              feedback.type === 'correct' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
            }`}>
              {feedback.type === 'correct' ? '✓ Correct!' : '✗ Wrong'} ({feedback.channel})
            </span>
          )}
        </div>

        <div className="flex gap-4">
          <button
            onClick={handlePositionPress}
            disabled={phase !== 'playing' || currentIndex < classicSettings.n || positionResponses.has(currentIndex)}
            className={`flex-1 py-5 rounded-2xl font-bold text-base ${anims ? 'transition-all duration-150 active:scale-95' : ''} disabled:opacity-30 ${
              positionResponses.has(currentIndex)
                ? 'bg-brand-500/30 text-brand-300'
                : dark
                  ? 'bg-dark-surface border-2 border-brand-500/50 text-brand-300 hover:bg-brand-500/10'
                  : 'bg-white border-2 border-brand-400 text-brand-600 shadow-sm'
            }`}
          >
            📍 Position
          </button>
          <button
            onClick={handleAudioPress}
            disabled={phase !== 'playing' || currentIndex < classicSettings.n || audioResponses.has(currentIndex)}
            className={`flex-1 py-5 rounded-2xl font-bold text-base ${anims ? 'transition-all duration-150 active:scale-95' : ''} disabled:opacity-30 ${
              audioResponses.has(currentIndex)
                ? 'bg-neon-cyan/30 text-neon-cyan'
                : dark
                  ? 'bg-dark-surface border-2 border-neon-cyan/50 text-neon-cyan hover:bg-neon-cyan/10'
                  : 'bg-white border-2 border-teal-400 text-teal-600 shadow-sm'
            }`}
          >
            🔊 Audio
          </button>
        </div>
      </div>
    </div>
  );
}
