import { useState, useEffect, useCallback, useRef } from 'react';
import { useStore } from '../../store/useStore';
import { SHAPES, COLORS, getLetterForIndex } from '../../utils/stimulusGenerator';
import { speakLetter, playPianoNote, speakNumber, playCorrectSound, playWrongSound, startNoise, stopNoise } from '../../utils/audio';
import { X, Pause, Play } from 'lucide-react';

interface ChannelState {
  values: number[];
  currentIndex: number;
  matches: boolean[];
  speed: number;
  n: number;
}

interface ChannelResult {
  hits: number; misses: number; falseAlarms: number; correctRejections: number; accuracy: number;
}

export function AlienGame() {
  const { settings, alienSettings, setScreen, addSession, addXP } = useStore();
  const dark = settings.theme === 'dark';
  const anims = settings.animationsEnabled;

  const [phase, setPhase] = useState<'ready' | 'playing' | 'paused' | 'result'>('ready');
  const [channelStates, setChannelStates] = useState<Record<string, ChannelState>>({});
  const [responses, setResponses] = useState<Record<string, Set<number>>>({});
  const [results, setResults] = useState<Record<string, ChannelResult>>({});
  const [totalAccuracy, setTotalAccuracy] = useState(0);
  const [showStimulus, setShowStimulus] = useState<Record<string, boolean>>({});
  const [startTime, setStartTime] = useState(0);
  const [opacity, setOpacity] = useState(1);
  const [visualNoise, setVisualNoise] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'correct' | 'wrong' | null; channel: string }>({ type: null, channel: '' });
  const [activeButtons, setActiveButtons] = useState<Set<string>>(new Set());
  const [gameFinished, setGameFinished] = useState(false);

  const timersRef = useRef<Record<string, ReturnType<typeof setTimeout>>>({});
  const pauseRef = useRef(false);
  const channelStatesRef = useRef<Record<string, ChannelState>>({});

  const activeChannels: string[] = [];
  if (alienSettings.channels.position) activeChannels.push('position');
  if (alienSettings.channels.audio) activeChannels.push('audio');
  if (alienSettings.channels.color) activeChannels.push('color');
  if (alienSettings.channels.shape) activeChannels.push('shape');

  // Calculate stimuli count per channel based on speed ratios
  const calcStimuliCounts = useCallback(() => {
    const speeds: Record<string, number> = {};
    for (const ch of activeChannels) {
      speeds[ch] = alienSettings.channelSpeed[ch] ?? 2500;
    }
    // Find the slowest channel's total time
    const baseCount = alienSettings.stimuliCount;
    const avgSpeed = Object.values(speeds).reduce((a, b) => a + b, 0) / activeChannels.length;
    const totalTime = baseCount * avgSpeed;

    const counts: Record<string, number> = {};
    for (const ch of activeChannels) {
      counts[ch] = Math.max(10, Math.round(totalTime / speeds[ch]));
    }
    return counts;
  }, [alienSettings, activeChannels]);

  const generateGame = useCallback(() => {
    const counts = calcStimuliCounts();
    const states: Record<string, ChannelState> = {};
    const resps: Record<string, Set<number>> = {};
    const shows: Record<string, boolean> = {};

    for (const ch of activeChannels) {
      const n = alienSettings.channelN[ch] ?? 2;
      const speed = alienSettings.channelSpeed[ch] ?? 2500;
      const count = counts[ch];
      const matchCount = Math.round(count * alienSettings.matchPercent / 100);

      // Generate values
      const range = ch === 'position' ? (alienSettings.channels.gridSize * alienSettings.channels.gridSize)
        : ch === 'audio' ? 9 : ch === 'color' ? COLORS.length : SHAPES.length;

      const values: number[] = [];
      const matches: boolean[] = [];

      // Determine match positions
      const matchPositions = new Set<number>();
      const available = [];
      for (let i = n; i < count; i++) available.push(i);
      const shuffled = [...available].sort(() => Math.random() - 0.5);
      for (let i = 0; i < Math.min(matchCount, shuffled.length); i++) {
        matchPositions.add(shuffled[i]);
      }

      for (let i = 0; i < count; i++) {
        if (i >= n && matchPositions.has(i)) {
          values.push(values[i - n]);
          matches.push(true);
        } else {
          let val = Math.floor(Math.random() * range);
          if (i >= n && val === values[i - n]) {
            val = (val + 1) % range;
          }
          values.push(val);
          matches.push(false);
        }
      }

      states[ch] = { values, currentIndex: -1, matches, speed, n };
      resps[ch] = new Set();
      shows[ch] = false;
    }

    setChannelStates(states);
    channelStatesRef.current = states;
    setResponses(resps);
    setShowStimulus(shows);
    setActiveButtons(new Set(activeChannels));
    setGameFinished(false);
  }, [alienSettings, activeChannels, calcStimuliCounts]);

  useEffect(() => { generateGame(); }, []);

  const advanceChannel = useCallback((ch: string) => {
    if (pauseRef.current) return;

    setChannelStates(prev => {
      const state = prev[ch];
      if (!state) return prev;
      const newIndex = state.currentIndex + 1;

      if (newIndex >= state.values.length) {
        // Channel finished
        return prev;
      }

      const updated = { ...prev, [ch]: { ...state, currentIndex: newIndex } };
      channelStatesRef.current = updated;

      // Play audio for audio channel
      if (ch === 'audio' && alienSettings.channels.audio) {
        const types = alienSettings.channels.audioType;
        const type = types[Math.floor(Math.random() * types.length)];
        const val = state.values[newIndex];
        const rate = Math.max(0.7, Math.min(2.5, 2500 / state.speed));
        if (type === 'piano') playPianoNote(val, state.speed * 0.7);
        else if (type === 'letters') speakLetter(getLetterForIndex(val), rate);
        else speakNumber((val % 20) + 1, rate);
      }

      return updated;
    });

    setShowStimulus(prev => ({ ...prev, [ch]: true }));

    // Interference
    if (alienSettings.interference.opacityEnabled) {
      const chance = alienSettings.interference.opacityIntensity / 10;
      if (Math.random() < chance) {
        setOpacity(0.2 + Math.random() * 0.3);
        setTimeout(() => setOpacity(1), 500);
      }
    }
    if (alienSettings.interference.visualNoiseEnabled) {
      setVisualNoise(Math.random() < alienSettings.interference.visualNoiseIntensity / 10);
    }

    // Channel switching
    if (alienSettings.taskSwitching.channelSwitching) {
      const chance = alienSettings.taskSwitching.channelSwitchingIntensity / 12;
      if (Math.random() < chance) {
        const numShow = Math.max(1, Math.floor(Math.random() * activeChannels.length));
        const sh = [...activeChannels].sort(() => Math.random() - 0.5);
        setActiveButtons(new Set(sh.slice(0, numShow)));
      }
    }

    // Schedule hide
    const state = channelStatesRef.current[ch];
    if (state) {
      setTimeout(() => {
        setShowStimulus(prev => ({ ...prev, [ch]: false }));
      }, Math.min(state.speed * 0.7, state.speed - 100));
    }
  }, [alienSettings, activeChannels]);

  // Start independent timers for each channel
  const startGame = useCallback(() => {
    setPhase('playing');
    setStartTime(Date.now());

    if (alienSettings.interference.noiseType !== 'none') {
      startNoise(alienSettings.interference.noiseType, alienSettings.interference.noiseIntensity);
    }

    // Start each channel with its own interval
    for (const ch of activeChannels) {
      const speed = alienSettings.channelSpeed[ch] ?? 2500;

      const runChannel = () => {
        if (pauseRef.current) {
          timersRef.current[ch] = setTimeout(runChannel, 100);
          return;
        }

        const state = channelStatesRef.current[ch];
        if (!state || state.currentIndex >= state.values.length - 1) {
          // Check if all channels are done
          const allDone = activeChannels.every(c => {
            const s = channelStatesRef.current[c];
            return s && s.currentIndex >= s.values.length - 1;
          });
          if (allDone) {
            setGameFinished(true);
          }
          return;
        }

        advanceChannel(ch);

        // Dynamic speed
        let nextSpeed = speed;
        if (alienSettings.taskSwitching.dynamicSpeed) {
          const chance = alienSettings.taskSwitching.dynamicSpeedIntensity / 10;
          if (Math.random() < chance) {
            nextSpeed = Math.floor(Math.random() * (alienSettings.taskSwitching.dynamicSpeedMax - alienSettings.taskSwitching.dynamicSpeedMin + 1)) + alienSettings.taskSwitching.dynamicSpeedMin;
          }
        }

        timersRef.current[ch] = setTimeout(runChannel, nextSpeed);
      };

      // Initial advance
      setTimeout(() => {
        advanceChannel(ch);
        timersRef.current[ch] = setTimeout(runChannel, speed);
      }, Math.random() * 500); // Stagger starts slightly
    }
  }, [alienSettings, activeChannels, advanceChannel]);

  // Check if game is done
  useEffect(() => {
    if (gameFinished && phase === 'playing') {
      setPhase('result');
      stopNoise();
      for (const t of Object.values(timersRef.current)) clearTimeout(t);
    }
  }, [gameFinished, phase]);

  // Calculate results
  useEffect(() => {
    if (phase !== 'result') return;
    stopNoise();

    const channelResults: Record<string, ChannelResult> = {};
    let totalAcc = 0;

    for (const ch of activeChannels) {
      const state = channelStates[ch];
      if (!state) continue;
      const resp = responses[ch] ?? new Set();
      let hits = 0, misses = 0, falseAlarms = 0, correctRejections = 0;

      for (let i = 0; i < state.values.length; i++) {
        const isMatch = state.matches[i];
        const responded = resp.has(i);
        if (isMatch && responded) hits++;
        else if (isMatch && !responded) misses++;
        else if (!isMatch && responded) falseAlarms++;
        else correctRejections++;
      }

      const totalMatches = hits + misses;
      const hitRate = totalMatches > 0 ? hits / totalMatches : 0;
      const faPenalty = falseAlarms > 0 ? (falseAlarms / (falseAlarms + correctRejections)) * 0.5 : 0;
      const accuracy = Math.max(0, Math.min(100, (hitRate * 100) - (faPenalty * 30)));

      channelResults[ch] = { hits, misses, falseAlarms, correctRejections, accuracy };
      totalAcc += accuracy;
    }

    const avg = activeChannels.length > 0 ? totalAcc / activeChannels.length : 0;
    setResults(channelResults);
    setTotalAccuracy(avg);

    const duration = Math.round((Date.now() - startTime) / 1000);
    const xp = Math.round(avg * 1.0 + activeChannels.length * 15 + 20);
    addSession({
      mode: 'alien',
      date: new Date().toISOString(),
      accuracy: avg,
      n: Math.max(...activeChannels.map(ch => alienSettings.channelN[ch] ?? 2)),
      channels: activeChannels,
      hits: Object.values(channelResults).reduce((a, r) => a + r.hits, 0),
      misses: Object.values(channelResults).reduce((a, r) => a + r.misses, 0),
      falseAlarms: Object.values(channelResults).reduce((a, r) => a + r.falseAlarms, 0),
      correctRejections: Object.values(channelResults).reduce((a, r) => a + r.correctRejections, 0),
      xpEarned: xp,
      duration,
      channelDetails: channelResults,
    });
    addXP(xp);
  }, [phase]);

  const handleResponse = (channel: string) => {
    if (phase !== 'playing') return;
    const state = channelStates[channel];
    if (!state) return;
    const idx = state.currentIndex;
    if (idx < state.n) return;
    if (responses[channel]?.has(idx)) return;

    setResponses(prev => {
      const s = new Set(prev[channel]);
      s.add(idx);
      return { ...prev, [channel]: s };
    });

    const isMatch = state.matches[idx];
    if (isMatch) {
      setFeedback({ type: 'correct', channel });
      if (settings.soundEnabled) playCorrectSound();
    } else {
      setFeedback({ type: 'wrong', channel });
      if (settings.soundEnabled) playWrongSound();
    }
    setTimeout(() => setFeedback({ type: null, channel: '' }), 300);
  };

  const togglePause = () => {
    if (phase === 'playing') {
      pauseRef.current = true;
      setPhase('paused');
    } else if (phase === 'paused') {
      pauseRef.current = false;
      setPhase('playing');
    }
  };

  const cleanup = () => {
    stopNoise();
    for (const t of Object.values(timersRef.current)) clearTimeout(t);
    setScreen('alien-settings');
  };

  const channelEmoji: Record<string, string> = { position: '📍', audio: '🔊', color: '🎨', shape: '🔷' };

  if (phase === 'ready') {
    return (
      <div className={`h-full flex flex-col items-center justify-center ${dark ? 'bg-dark-bg text-dark-text' : 'bg-gray-50 text-gray-900'}`}>
        <div className={`w-24 h-24 rounded-3xl flex items-center justify-center bg-gradient-to-br from-neon-pink to-red-600 mb-6 ${anims ? 'animate-pulse-glow' : ''}`}>
          <span className="text-5xl">👽</span>
        </div>
        <h2 className="text-2xl font-black mb-2">Alien Mode</h2>
        <p className={`text-sm mb-1 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>{activeChannels.length} channels • Independent speeds</p>
        <p className={`text-xs mb-8 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>{activeChannels.map(c => channelEmoji[c]).join(' ')}</p>
        <button onClick={startGame} className="w-20 h-20 rounded-full bg-gradient-to-r from-neon-pink to-red-600 flex items-center justify-center shadow-lg shadow-neon-pink/40 active:scale-95 transition-transform">
          <Play className="w-10 h-10 text-white ml-1" />
        </button>
        <button onClick={() => setScreen('alien-settings')} className={`mt-6 text-sm ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>← Back</button>
      </div>
    );
  }

  if (phase === 'result') {
    return (
      <div className={`h-full flex flex-col ${dark ? 'bg-dark-bg text-dark-text' : 'bg-gray-50 text-gray-900'}`}>
        <div className="px-5 pt-6 pb-4 flex items-center justify-between">
          <h1 className="text-xl font-bold">Results</h1>
          <button onClick={cleanup} className={`w-10 h-10 rounded-xl flex items-center justify-center ${dark ? 'bg-dark-surface' : 'bg-white shadow-sm'}`}><X className="w-5 h-5" /></button>
        </div>
        <div className="flex-1 overflow-y-auto px-5 pb-6 space-y-4">
          <div className={`rounded-3xl p-6 text-center ${dark ? 'bg-dark-card border border-dark-border' : 'bg-white shadow-sm'}`}>
            <p className={`text-xs uppercase tracking-wider mb-2 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Overall Accuracy</p>
            <p className={`text-6xl font-black ${totalAccuracy >= 80 ? 'text-green-400' : totalAccuracy >= 50 ? 'text-yellow-400' : 'text-red-400'}`}>{totalAccuracy.toFixed(1)}%</p>
          </div>

          {activeChannels.map(ch => {
            const r = results[ch];
            if (!r) return null;
            return (
              <div key={ch} className={`rounded-3xl p-5 ${dark ? 'bg-dark-card border border-dark-border' : 'bg-white shadow-sm'}`}>
                <h3 className="font-bold text-sm mb-3">{channelEmoji[ch]} {ch} (N={alienSettings.channelN[ch] ?? 2})</h3>
                <div className="grid grid-cols-4 gap-2 mb-2">
                  <div className="text-center"><p className="text-green-400 text-lg font-black">{r.hits}</p><p className={`text-[9px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Hits</p></div>
                  <div className="text-center"><p className="text-red-400 text-lg font-black">{r.misses}</p><p className={`text-[9px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>Miss</p></div>
                  <div className="text-center"><p className="text-orange-400 text-lg font-black">{r.falseAlarms}</p><p className={`text-[9px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>FA</p></div>
                  <div className="text-center"><p className="text-blue-400 text-lg font-black">{r.correctRejections}</p><p className={`text-[9px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>CR</p></div>
                </div>
                <div className={`h-2 rounded-full overflow-hidden ${dark ? 'bg-dark-border' : 'bg-gray-200'}`}>
                  <div className={`h-full rounded-full ${r.accuracy >= 80 ? 'bg-green-400' : r.accuracy >= 50 ? 'bg-yellow-400' : 'bg-red-400'}`} style={{ width: `${r.accuracy}%` }} />
                </div>
                <p className="text-right text-xs font-bold mt-1">{r.accuracy.toFixed(1)}%</p>
              </div>
            );
          })}

          <div className="flex gap-3">
            <button onClick={() => { generateGame(); setPhase('ready'); }} className="flex-1 py-3 rounded-2xl font-bold text-sm bg-gradient-to-r from-neon-pink to-red-600 text-white">Again</button>
            <button onClick={() => { cleanup(); setScreen('home'); }} className={`flex-1 py-3 rounded-2xl font-bold text-sm ${dark ? 'bg-dark-surface text-dark-text' : 'bg-gray-100 text-gray-700'}`}>Home</button>
          </div>
        </div>
      </div>
    );
  }

  // Playing screen - 4 quadrants
  const gridSize = alienSettings.channels.gridSize;
  const posState = channelStates['position'];
  const posVal = posState && posState.currentIndex >= 0 ? posState.values[posState.currentIndex] : -1;

  return (
    <div className={`h-full flex flex-col ${dark ? 'bg-dark-bg text-dark-text' : 'bg-gray-50 text-gray-900'}`} style={{ opacity }}>
      {phase === 'paused' && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/70">
          <div className="text-center">
            <p className="text-3xl font-black text-white mb-4">⏸ Paused</p>
            <button onClick={togglePause} className="px-8 py-3 rounded-2xl bg-gradient-to-r from-neon-pink to-red-600 text-white font-bold">Resume</button>
          </div>
        </div>
      )}

      {visualNoise && (
        <div className="absolute inset-0 z-10 pointer-events-none opacity-30"
          style={{ background: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")` }} />
      )}

      <div className="px-4 pt-3 pb-1 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className={`text-xs font-bold px-2 py-1 rounded-lg ${dark ? 'bg-neon-pink/20 text-neon-pink' : 'bg-red-50 text-red-600'}`}>
            ALIEN
          </span>
          {activeChannels.map(ch => (
            <span key={ch} className={`text-[10px] ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>
              {channelEmoji[ch]}{(channelStates[ch]?.currentIndex ?? 0) + 1}/{channelStates[ch]?.values.length ?? 0}
            </span>
          ))}
        </div>
        <div className="flex gap-1">
          <button onClick={togglePause} className={`w-8 h-8 rounded-lg flex items-center justify-center ${dark ? 'bg-dark-surface' : 'bg-white shadow-sm'}`}>
            {phase === 'paused' ? <Play className="w-3 h-3" /> : <Pause className="w-3 h-3" />}
          </button>
          <button onClick={cleanup} className={`w-8 h-8 rounded-lg flex items-center justify-center ${dark ? 'bg-dark-surface' : 'bg-white shadow-sm'}`}>
            <X className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* 4 Quadrants */}
      <div className="flex-1 grid grid-cols-2 grid-rows-2 gap-2 px-3 py-2">
        {/* Position quadrant */}
        {alienSettings.channels.position && (
          <div className={`rounded-2xl p-2 ${dark ? 'bg-dark-card border border-dark-border' : 'bg-white border border-gray-100'}`}>
            <p className={`text-[9px] font-bold mb-1 ${dark ? 'text-neon-pink' : 'text-red-500'}`}>📍 POS N={alienSettings.channelN['position'] ?? 2}</p>
            <div className="grid gap-0.5 aspect-square" style={{ gridTemplateColumns: `repeat(${gridSize}, 1fr)` }}>
              {Array.from({ length: gridSize * gridSize }, (_, i) => (
                <div key={i} className={`rounded ${showStimulus['position'] && posVal === i
                  ? 'bg-neon-pink/60 border border-neon-pink'
                  : dark ? 'bg-dark-surface/50' : 'bg-gray-100/50'
                }`} />
              ))}
            </div>
          </div>
        )}

        {/* Audio quadrant */}
        {alienSettings.channels.audio && (
          <div className={`rounded-2xl p-2 flex flex-col items-center justify-center ${dark ? 'bg-dark-card border border-dark-border' : 'bg-white border border-gray-100'}`}>
            <p className={`text-[9px] font-bold mb-2 ${dark ? 'text-neon-cyan' : 'text-teal-500'}`}>🔊 AUD N={alienSettings.channelN['audio'] ?? 2}</p>
            {showStimulus['audio'] && channelStates['audio'] && (
              <div className="text-4xl">
                {(() => {
                  const val = channelStates['audio'].values[channelStates['audio'].currentIndex];
                  return <span className="font-black">{getLetterForIndex(val)}</span>;
                })()}
              </div>
            )}
          </div>
        )}

        {/* Color quadrant */}
        {alienSettings.channels.color && (
          <div className={`rounded-2xl p-2 flex flex-col items-center justify-center ${dark ? 'bg-dark-card border border-dark-border' : 'bg-white border border-gray-100'}`}>
            <p className={`text-[9px] font-bold mb-2 ${dark ? 'text-yellow-400' : 'text-yellow-600'}`}>🎨 CLR N={alienSettings.channelN['color'] ?? 2}</p>
            {showStimulus['color'] && channelStates['color'] && (
              <div className="w-16 h-16 rounded-2xl" style={{ backgroundColor: COLORS[channelStates['color'].values[channelStates['color'].currentIndex] % COLORS.length] }} />
            )}
          </div>
        )}

        {/* Shape quadrant */}
        {alienSettings.channels.shape && (
          <div className={`rounded-2xl p-2 flex flex-col items-center justify-center ${dark ? 'bg-dark-card border border-dark-border' : 'bg-white border border-gray-100'}`}>
            <p className={`text-[9px] font-bold mb-2 ${dark ? 'text-neon-green' : 'text-green-600'}`}>🔷 SHP N={alienSettings.channelN['shape'] ?? 2}</p>
            {showStimulus['shape'] && channelStates['shape'] && (
              <span className="text-5xl" style={{ color: dark ? '#fff' : '#333' }}>
                {['●','■','▲','◆','★','⬡','⬠','✚','♥'][channelStates['shape'].values[channelStates['shape'].currentIndex] % SHAPES.length]}
              </span>
            )}
          </div>
        )}

        {/* Fill empty quadrants */}
        {Array.from({ length: Math.max(0, 4 - activeChannels.length) }, (_, i) => (
          <div key={`empty-${i}`} className={`rounded-2xl ${dark ? 'bg-dark-card/30 border border-dark-border/30' : 'bg-gray-50 border border-gray-100/50'}`} />
        ))}
      </div>

      {/* Response buttons */}
      <div className="px-3 pb-6 pt-2">
        <div className="h-5 flex items-center justify-center mb-2">
          {feedback.type && (
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${feedback.type === 'correct' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
              {feedback.type === 'correct' ? '✓' : '✗'} {feedback.channel}
            </span>
          )}
        </div>
        <div className="flex gap-2 justify-center">
          {activeChannels.filter(ch => activeButtons.has(ch)).map(ch => (
            <button
              key={ch}
              onClick={() => handleResponse(ch)}
              className={`flex-1 max-w-[90px] py-3 rounded-xl font-bold text-xs ${anims ? 'transition-all duration-100 active:scale-90' : ''} ${
                dark ? 'bg-dark-surface border border-dark-border text-dark-text' : 'bg-white border border-gray-200 text-gray-700 shadow-sm'
              }`}
            >
              {channelEmoji[ch]}<br />{ch.slice(0, 3).toUpperCase()}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
