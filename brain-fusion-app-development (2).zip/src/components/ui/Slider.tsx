/* Slider component */
import { useStore } from '../../store/useStore';

interface SliderProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (v: number) => void;
  unit?: string;
  formatValue?: (v: number) => string;
}

export function Slider({ label, value, min, max, step = 1, onChange, unit = '', formatValue }: SliderProps) {
  const dark = useStore(s => s.settings.theme) === 'dark';
  const display = formatValue ? formatValue(value) : `${value}${unit}`;
  const pct = ((value - min) / (max - min)) * 100;

  return (
    <div className="w-full space-y-2">
      <div className="flex items-center justify-between">
        <span className={`text-sm font-medium ${dark ? 'text-dark-text' : 'text-gray-700'}`}>{label}</span>
        <span className={`text-sm font-bold px-2 py-0.5 rounded-lg ${dark ? 'bg-brand-500/20 text-brand-300' : 'bg-brand-50 text-brand-600'}`}>{display}</span>
      </div>
      <div className="relative">
        <div className={`w-full h-2 rounded-full ${dark ? 'bg-dark-border' : 'bg-gray-200'}`}>
          <div
            className="h-full rounded-full bg-gradient-to-r from-brand-500 to-neon-cyan"
            style={{ width: `${pct}%` }}
          />
        </div>
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={e => onChange(Number(e.target.value))}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        />
      </div>
    </div>
  );
}
