import { useStore } from '../../store/useStore';

interface ToggleProps {
  label: string;
  value: boolean;
  onChange: (v: boolean) => void;
  description?: string;
}

export function Toggle({ label, value, onChange, description }: ToggleProps) {
  const dark = useStore(s => s.settings.theme) === 'dark';
  const anims = useStore(s => s.settings.animationsEnabled);

  return (
    <div className="flex items-center justify-between py-2">
      <div className="flex-1">
        <span className={`text-sm font-medium ${dark ? 'text-dark-text' : 'text-gray-700'}`}>{label}</span>
        {description && <p className={`text-xs mt-0.5 ${dark ? 'text-dark-muted' : 'text-gray-400'}`}>{description}</p>}
      </div>
      <button
        onClick={() => onChange(!value)}
        className={`relative w-12 h-7 rounded-full ${anims ? 'transition-colors duration-300' : ''} ${
          value
            ? 'bg-gradient-to-r from-brand-500 to-neon-cyan'
            : dark ? 'bg-dark-border' : 'bg-gray-300'
        }`}
      >
        <div
          className={`absolute top-0.5 w-6 h-6 rounded-full bg-white shadow-md ${anims ? 'transition-transform duration-300' : ''} ${
            value ? 'translate-x-5.5' : 'translate-x-0.5'
          }`}
        />
      </button>
    </div>
  );
}
