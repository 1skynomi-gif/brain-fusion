import React from 'react';
import { useStore } from '../../store/useStore';

interface ButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'neon';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  className?: string;
  icon?: React.ReactNode;
}

export function Button({ children, onClick, variant = 'primary', size = 'md', disabled, className = '', icon }: ButtonProps) {
  const theme = useStore(s => s.settings.theme);
  const anims = useStore(s => s.settings.animationsEnabled);
  const dark = theme === 'dark';

  const base = `inline-flex items-center justify-center gap-2 font-semibold rounded-2xl ${anims ? 'transition-all duration-300' : ''} active:scale-95 disabled:opacity-40 disabled:pointer-events-none`;

  const sizes = {
    sm: 'px-3 py-1.5 text-xs',
    md: 'px-5 py-2.5 text-sm',
    lg: 'px-7 py-3.5 text-base',
  };

  const variants = {
    primary: dark
      ? 'bg-gradient-to-r from-brand-500 to-brand-600 text-white shadow-lg shadow-brand-500/25 hover:shadow-brand-500/40'
      : 'bg-gradient-to-r from-brand-500 to-brand-600 text-white shadow-lg shadow-brand-500/25 hover:shadow-brand-500/40',
    secondary: dark
      ? 'bg-dark-surface text-dark-text border border-dark-border hover:bg-dark-border'
      : 'bg-gray-100 text-gray-800 border border-gray-200 hover:bg-gray-200',
    ghost: dark
      ? 'text-dark-muted hover:text-dark-text hover:bg-dark-surface'
      : 'text-gray-500 hover:text-gray-800 hover:bg-gray-100',
    danger: 'bg-gradient-to-r from-red-500 to-red-600 text-white shadow-lg shadow-red-500/25',
    neon: dark
      ? 'bg-transparent border-2 border-neon-cyan text-neon-cyan shadow-lg shadow-neon-cyan/20 hover:bg-neon-cyan/10'
      : 'bg-transparent border-2 border-brand-500 text-brand-600 hover:bg-brand-50',
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`${base} ${sizes[size]} ${variants[variant]} ${className}`}
    >
      {icon && <span className="w-5 h-5">{icon}</span>}
      {children}
    </button>
  );
}
