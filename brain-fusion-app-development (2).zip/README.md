# 🧠 Brain Fusion

Professional cognitive training application with N-Back exercises.

## Features

- **4 Game Modes**: Classic, Advanced, Arithmetic, Alien
- **Multi-channel N-Back**: Position, Audio, Shape, Color, and more
- **Adaptive Difficulty**: Auto-adjusts based on performance
- **Dark/Light Theme**: Full theme support
- **Profile System**: XP, Levels, and Titles
- **Detailed Analytics**: Per-channel accuracy breakdown

---

## 🚀 Quick Start (Web)

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build
```

---

## 📱 Build Android APK

### Method 1: Using Capacitor (Recommended)

#### Step 1: Install Dependencies
```bash
npm install
npm install @capacitor/core @capacitor/cli @capacitor/android
```

#### Step 2: Build Web App
```bash
npm run build
```

#### Step 3: Initialize Capacitor
```bash
npx cap init "Brain Fusion" "com.brainfusion.app" --web-dir dist
```

#### Step 4: Add Android Platform
```bash
npx cap add android
```

#### Step 5: Sync Files
```bash
npx cap sync android
```

#### Step 6: Open in Android Studio
```bash
npx cap open android
```

#### Step 7: Build APK
In Android Studio:
1. Go to `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`
2. APK will be in `android/app/build/outputs/apk/debug/`

---

### Method 2: Using Online Services

#### Option A: PWABuilder.com
1. Go to https://pwabuilder.com
2. Enter your deployed URL (e.g., GitHub Pages URL)
3. Click "Start"
4. Go to "Android" tab
5. Download APK

#### Option B: Bubblewrap (Google's Tool)
```bash
npm install -g @aspect/aspect-tool
npx bubblewrap init --manifest https://YOUR_URL/manifest.json
npx bubblewrap build
```

---

## 🌐 Deploy to GitHub Pages

### Step 1: Create Repository
1. Go to github.com and create new repository
2. Name it (e.g., `brain-fusion`)

### Step 2: Update vite.config.ts
Add base path for GitHub Pages:
```typescript
export default defineConfig({
  base: '/brain-fusion/', // your repo name
  // ... rest of config
})
```

### Step 3: Build and Deploy
```bash
npm run build
```

### Step 4: Upload to GitHub
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/brain-fusion.git
git push -u origin main
```

### Step 5: Enable GitHub Pages
1. Go to repository Settings
2. Go to Pages section
3. Select source: "GitHub Actions" or "Deploy from branch"
4. Select branch: `main`, folder: `/dist`
5. Save

Your app will be at: `https://YOUR_USERNAME.github.io/brain-fusion/`

---

## 📁 Project Structure

```
brain-fusion/
├── public/
│   ├── manifest.json      # PWA manifest
│   └── icons/             # App icons (create these)
├── src/
│   ├── components/
│   │   ├── game/          # Game components
│   │   ├── screens/       # Screen components
│   │   └── ui/            # UI components
│   ├── store/
│   │   └── useStore.ts    # Zustand state management
│   ├── utils/
│   │   ├── audio.ts       # Audio utilities
│   │   └── stimulusGenerator.ts  # Stimulus generation
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── capacitor.config.json  # Capacitor config
├── index.html
├── package.json
├── tsconfig.json
└── vite.config.ts
```

---

## 🎨 Create App Icons

You need to create icons for the app. Use any icon generator:

1. Go to https://icon.kitchen or https://realfavicongenerator.net
2. Upload a 1024x1024 PNG of your icon
3. Download all sizes
4. Place in `public/icons/` folder

Required sizes:
- 72x72, 96x96, 128x128, 144x144
- 152x152, 192x192, 384x384, 512x512

---

## 🔧 Tech Stack

- **React 19** - UI Framework
- **Vite** - Build Tool
- **TypeScript** - Type Safety
- **Tailwind CSS 4** - Styling
- **Zustand** - State Management
- **Framer Motion** - Animations
- **Lucide React** - Icons
- **Web Speech API** - Text-to-Speech

---

## 📄 License

MIT License - Feel free to use and modify!

---

## 🧪 Game Modes Explained

### Classic N-Back
- 2 channels: Position (3×3 grid) + Audio (letters)
- N: 1-10
- Fixed 25% match rate

### Advanced N-Back
- Up to 10 channels
- N: 1-100
- Interference effects (noise, lures, fading)
- Dynamic N and Speed

### Arithmetic N-Back
- Math operations with N-Back
- Add, Subtract, Multiply
- Comparison tasks

### Alien Mode
- Independent channel speeds
- 4-quadrant display
- Auto-balanced stimuli counts

---

Made with 🧠 for cognitive enhancement!
