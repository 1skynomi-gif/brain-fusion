# 🧠 Brain Fusion - راهنمای ساخت APK

## 📋 فایل‌های پروژه

پروژه شامل این فایل‌ها است:
```
brain-fusion/
├── public/
│   ├── manifest.json          ← تنظیمات PWA
│   └── icons/
│       ├── icon-192x192.png   ← آیکون کوچک
│       └── icon-512x512.png   ← آیکون بزرگ
├── src/                       ← کد اصلی برنامه
├── dist/                      ← خروجی ساخته شده (همین رو آپلود کن)
├── capacitor.config.json      ← تنظیمات اندروید
├── index.html
├── package.json
└── README.md
```

---

## 🚀 روش ۱: استفاده از PWABuilder (ساده‌ترین روش)

### مرحله ۱: آپلود به GitHub Pages

1. **ساخت ریپو در GitHub:**
   - برو به github.com
   - یک Repository جدید بساز (مثلاً `brain-fusion`)
   - Public باشد

2. **آپلود فایل‌ها:**
   - محتوای پوشه `dist` را آپلود کن
   - یا کل پروژه را آپلود کن

3. **فعال کردن GitHub Pages:**
   - برو به Settings ریپو
   - بخش Pages
   - Source را روی `Deploy from a branch` بگذار
   - Branch را `main` و پوشه را `/dist` یا `/(root)` انتخاب کن
   - Save کن

4. **آدرس سایت:**
   ```
   https://YOUR_USERNAME.github.io/brain-fusion/
   ```

### مرحله ۲: ساخت APK با PWABuilder

1. برو به: **https://pwabuilder.com**

2. آدرس سایت GitHub Pages خودت را وارد کن

3. روی **Start** کلیک کن

4. صبر کن تا آنالیز تمام شود

5. برو به تب **Android**

6. روی **Generate** کلیک کن

7. فایل APK را دانلود کن

8. APK روی گوشی نصب کن! 🎉

---

## 🚀 روش ۲: استفاده از Capacitor (حرفه‌ای‌تر)

### نیازمندی‌ها:
- Node.js نصب باشد
- Android Studio نصب باشد

### مراحل:

```bash
# ۱. نصب وابستگی‌ها
npm install
npm install @capacitor/core @capacitor/cli @capacitor/android

# ۲. ساخت پروژه
npm run build

# ۳. اضافه کردن اندروید
npx cap add android

# ۴. همگام‌سازی
npx cap sync android

# ۵. باز کردن در Android Studio
npx cap open android
```

در Android Studio:
1. صبر کن تا Gradle sync تمام شود
2. برو به `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`
3. APK در این مسیر ساخته می‌شود:
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```

---

## 🚀 روش ۳: استفاده از سرویس‌های آنلاین دیگر

### AppsGeyser.com
1. برو به https://appsgeyser.com
2. انتخاب کن "Website to App"
3. آدرس GitHub Pages را وارد کن
4. APK را دانلود کن

### WebIntoApp.com
1. برو به https://webintoapp.com
2. آدرس را وارد کن
3. APK بگیر

---

## ⚠️ نکات مهم

### درباره آیکون‌ها
اگر آیکون‌ها درست نمایش داده نشدند، آیکون‌های اضافی بساز:
- سایت https://icon.kitchen رو باز کن
- یک تصویر ۱۰۲۴×۱۰۲۴ آپلود کن
- همه سایزها را دانلود کن
- در پوشه `public/icons/` بگذار

### سایزهای لازم:
- icon-72x72.png
- icon-96x96.png
- icon-128x128.png
- icon-144x144.png
- icon-152x152.png
- icon-192x192.png ✓ (موجود)
- icon-384x384.png
- icon-512x512.png ✓ (موجود)

---

## 📱 تست APK

1. فایل APK را به گوشی منتقل کن
2. از File Manager باز کن
3. اجازه نصب از منابع ناشناس را بده
4. نصب کن
5. اجرا کن و لذت ببر! 🧠

---

## 🔧 اگر مشکلی پیش آمد

### مشکل ۱: PWABuilder خطا می‌دهد
- مطمئن شو manifest.json درست است
- مطمئن شو آیکون‌ها وجود دارند
- HTTPS باید فعال باشد (GitHub Pages خودکار دارد)

### مشکل ۲: صدا کار نمی‌کند
- اولین بار روی صفحه کلیک کن (مرورگر نیاز دارد)
- حجم صدای گوشی را چک کن

### مشکل ۳: APK نصب نمی‌شود
- تنظیمات → امنیت → منابع ناشناس را فعال کن
- یا از تنظیمات → برنامه‌ها → نصب برنامه‌های ناشناس

---

## 📞 پشتیبانی

اگر سوالی داشتی، در GitHub یک Issue باز کن!

موفق باشی! 🚀🧠
